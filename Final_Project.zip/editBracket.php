<!--
Group: Undergrad 3
filename: editBracket.html
Desc: Where the admin chooses which bracket to edit.
-->
<html>
<head>
	<title>Select</title>
<style>
.footer { 
	position: fixed; 
	bottom: 0; 
	}
.stroke2
	{
	color: white;
	text-shadow:
		-1px -1px 0 #000,
		1px -1px 0 #000,
		-1px 1px 0 #000,
		1px 1px 0 #000;
	}
</style>

</head>

<?php
//
//script to login into legacy database and display content
//
$hostname = "students";	//name of server
$username = "z1772281";	//username
$password = "1995May15";	//password
$db = "z1772281";	//name of database

//connecting to database
$conn = @mysql_connect($hostname,$username,$password);
if (!$conn) {
	die("Could not connect: " . mysql_error());
}

//select database
$db_selected = mysql_select_db($db, $conn);

if (!$db_selected) {
	die ("Could not use: " . $db . mysql_error());
}


//selection query
$sql = "SELECT * FROM internaldb WHERE number = '$_POST[id]'";

$result = mysql_query($sql, $conn);
//checking for failure
if (!$result) {
	die("Could not execute sql: " . mysql_error());
}

//echoing table headers
echo "<table align=center width=100%>";
	echo "<tr bgcolor=#416baf class=stroke2>";
	echo "<th align=left>Number</th>";
	echo "<th align=left>Description</th>";
	echo "<th align=left>Weight</th>";
	echo "</tr>";

// Loop that displays orders by variables accordingly
while($part=mysql_fetch_assoc($result)) {
	echo "<tr>";
	echo "<td align=left>".$part[number]."</td> ";
	echo "<td align=left>".$part[description]."</td> ";
	echo "<td align=left>".$part[weight]."</td> ";
	echo "</tr>";

}

echo "</table>";

echo "<br><p align=center>New Weight</p>";

echo "<form align=center method=post action=editBracketEnd.php>
	<input type=text name=newWeight>
	<input type=submit value=submit>
	<input type=hidden name=ID value='$_POST[id]'>
	</form>";

?>

</body>
</html>