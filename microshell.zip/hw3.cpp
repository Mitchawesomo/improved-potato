//********************************************************************
// CLASS:    CSCI 480-1
// PROGRAM:  Assignment 3
// AUTHOR:   Mitch Boehning
// Z-NUM:    z1751490
// DUE DATE: 04/04/2017
//
// PURPOSE:  Build a microshell that can do the following:
//           1. Print prompt "myshell>" and wait for input.
//           2. Execute command typed in, print new prompt
//           3. Shell knows "quit" and "q" commands to exit.
//           4. "||" allows piping of one command to next.
//
// EXECUTION: ./hw3.exe
//
// NOTES:
//
//*******************************************************************

#include <sys/utsname.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <string>

#include <cstdlib>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

using namespace std;

int main()
{

 std::string cmd_string; // used to store command
 std::string token; // Used for parse command

 char cmd_args[25]; // Used to store command arguments
 char* cmd_arr[25]; // Pointer to c-strings
 char *cmd_ptr; // Pointer

 // Used if there is a 2nd command (pipe)
 char cmd_args2[25];
 char* cmd_arr2[25];
 char *cmd_ptr2;

 std::istringstream iss; // Used to parse command
 int pid; // Child process
 int pid2; // Second child
 int fd[2]; // File descriptor [0] - read-end  [1] - write-end
 int ret; // used to create pipe
 bool pipe_flag = false; // used to create pipe if || found

 // Used to break up command if pipe
 std::string first_cmd;
 std::string second_cmd;

 // While being prompted
 while(1)
 {
   std::cout << "myshell>"; // Prepare for input

   getline(cin,cmd_string); // Store input into string

   // Exit shell if user wants to quit
   if(cmd_string == "quit")
   {
     exit(0);
   }

   // Exit shell if user wants to quit
   if(cmd_string == "q")
   {
     exit(0);
   }

   // Check if command contains pipe
   std::size_t found = cmd_string.find("||");

   if(found != std::string::npos)
   {
     //turn pipe flag on
     pipe_flag = true;
   }

   // If no pipe
   if(pipe_flag == false)
   {
     // Put string into istringstream
     iss.str(cmd_string);

     // Assign char array to pointer
     cmd_ptr = cmd_args;

     int i = 0; // Used to assign each pointer to right element in array

     // Tokenize input
     while(iss >> token) // Grab first command
     {
       const char * c = token.c_str(); // Convert to c-string

       strcpy(cmd_ptr, c); // Copy token into char array

       cmd_arr[i] = cmd_ptr; // Assign pointer to element

       i++; // increment pointer

       cmd_ptr += strlen(c) + 1; // Advance pointer for next argument
     }

     // Clear iss
     iss.clear();
     iss.str("");

     // Assign NULL to last element
     cmd_arr[i] = 0;

   } // end no pipe arg

   // Create pipe if needed
   if(pipe_flag == true)
   {
     ret = pipe(fd);

     if(ret == -1)
     {
       std::cout << "Pipe Failed " << ret << endl;
       exit(1);
     }

     // Copy Command string to 2nd command
     second_cmd = cmd_string;

     // Seperate Command by pipe
     std::string delimiter = "||";
     size_t pos = 0;

     while((pos = second_cmd.find(delimiter)) != std::string::npos)
     {
       first_cmd = second_cmd.substr(0,pos);

       second_cmd.erase(0, pos + delimiter.length() + 1);
     }

     // Parse up the two commands into seperate args
     // First command
     iss.str(first_cmd);

     // Assign char array to pointer
     cmd_ptr = cmd_args;

     int k = 0;

     // Tokenize
     while(iss >> token) // Grab first command
     {
       const char * e = token.c_str();

       strcpy(cmd_ptr, e);

       cmd_arr[k] = cmd_ptr;

       k++;

       cmd_ptr += strlen(e) + 1;
     }

     // Clear iss
     iss.clear();
     iss.str("");

     // Assign NULL to last arg
     cmd_arr[k] = 0;

     // Parse up 2nd command
     iss.str(second_cmd);

     // Assign char array to pointer
     cmd_ptr2 = cmd_args2;

     int j = 0; // Used to assign each pointer to right element in array

     // Tokenize input
     while(iss >> token) // Grab First command
     {
       const char * d = token.c_str(); // Convert to c-string

       strcpy(cmd_ptr2, d); // Copy token to char array

       cmd_arr2[j] = cmd_ptr2; // Assign pointer to element

       j++;

       cmd_ptr2 += strlen(d) + 1; // Advance pointer for next argument
     }

     // Clear iss
     iss.clear();
     iss.str("");

     // Assign NULL to last arg
     cmd_arr2[j] = 0;

   } // end if pipe == true

   // Create fork
   pid = fork();

   // Create another fork if pipe
   if(pipe_flag == true && pid > 0)
   {
     pid2 = fork();
   }

   // Check to make sure fork created
   if(pid < 0)
   {
     cout << "Fork failed " << endl;
     exit(-1);
   }
   if(pid == 0)                               // Now in First Fork
   {
     close(1); // close stdout

     std::cout << "after close" << endl;

     // Replacing stdout with pipe write
     if(dup(fd[1]) == -1)
     {
       std::cout << "dup error" << endl;
       exit(-1);
     }

     // Close pipe read
     close(fd[0]);
     close(fd[1]);

     // Perform execvp()
     if(execvp(cmd_arr[0], cmd_arr) < 0)
     {
       // Show error if Excevp does not work
       std::cout << "ERROR: Couldn't Execute: " << cmd_string << endl;
       exit(127);
     }

     exit(1);

   }// End First Fork

  // Set up second fork to redirect input of process out of pipe
  if(pipe_flag == true)
  {
    if(pid2 < 0)                               // Second Fork
    {
      std::cout << "2nd Fork Failed " << endl;
      exit(-1);
    }

    if(pid2 == 0)
    {
      close(0); // close stdin

      // Have stdin now point to fd[0]
      if(dup(fd[0]) == -1)
      {
        std::cout << "2nd dup error" << endl;
        exit(-1);
      }

      close(fd[1]); // Close pipe write
      close(fd[0]); // Close original pipe input

      // Perform other execvp()
      if(execvp(cmd_arr2[0], cmd_arr2) < 0)
      {
        // Error
        std::cout << "ERROR: Couldn't Execute: " << cmd_string << endl;
        exit(127);
      }

      exit(1);

    } // Exit 2nd child
  } // end pipe_flag == true
                                                     // Now in Parent

  // Check if pipes need to be closed
  if(pipe_flag == true)
  {
    // Close unused read-end
    close (fd[0]);

    // Close write-end
    close (fd[1]);
  }

  // Wait for child to finish
  if(waitpid(pid, 0, 0) < 0)
  {
    cout << "ERROR: Waitpid failed." << endl;
    exit(-1);
  }

  // Wait for both children if pipe
  if(pipe_flag == true)
  {
    if(waitpid(pid2, 0, 0) < 0)
    {
      cout << "ERROR: Waipid for both failed." << endl;
      exit(-1);
    }
  }

 } // Endwhile

 return 0;

} // end main
