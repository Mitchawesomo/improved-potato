package tiledesigner;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *
 * @author Mitch
 * z1751490
 * CSCI 470 LEON
 * Assignment 4: Tile Design
 * Due Date: November 9th, 2016
 * 
 * Purpose: This class holds all the interacting with the canvas grid.
 */
//this class works with the center grid and accesses the 2 arrays in TileDesignerLayout as well
class TileCanvas extends JPanel implements MouseListener
{
  int gridWidth;
  int gridHeight;
  int startX = 0;
  int startY = 0;
  int row, col; 
    
  public int selectedTile = -1; //this is set in other class with button clicks
  static final int squareSide = 25; // storage for pixel dimension
  final int gridRows = 5,gridCols = 5;	
  
  Image[][] gif_2dArray = new Image[gridRows][gridCols];// drawn on grid when we paint

  // this gets the name of the images out of array made in TileDesignerLayout and builds an array of type image
  public void LoadImageArray()
  {
      // Assigns each gif inside imageA array
      for(int i = 0; i < TileDesignerLayout.imageA.length; i++)
      {
          // Gets the names of images out of array and builds an array of type image
          TileDesignerLayout.imageA[i]=(Image)Toolkit.getDefaultToolkit().getImage(TileDesignerLayout.imageStringNameA[i]);
      }
  }
  
  // Method that resets the entire grid to empty
  public void ResetGridTile()
  {
      // set gif array to all null
      for(int row = 0; row < gridRows; row++)
      {
          for (int col = 0; col < gridCols; col++)
          {
              gif_2dArray[row][col] = null;
          }
      }
     this.repaint(); //draw empty grid
  } // End ResetGridTile
  
  public void CreateMouseListener()//Add mouselistener to Center panel
  { 
      addMouseListener(this);
  }

  //user has clicked a tile on panel, now has clicked in the 5 x 5 grid
  @Override
  public void mouseClicked(MouseEvent arg0)
  {          
     //here we get  a position of the click of mouse x and y
     int x = arg0.getX();
     int y = arg0.getY();

     //Checks to make sure x and y are within the grid lines.....making it a "valid click"
     if(x >= startX && x <= startX+gridWidth && y >= startY && y <= startY+gridWidth)
     {
       int xIndex = (x-startX)/squareSide; //will be an integer of square clicked
       int yIndex = (y-startY)/squareSide; //wil be an integer of square clicked
       
       //            col      row  
       // Selected tile 0-4 was set on other class with click on the menu area
       // move image into gif array position
       gif_2dArray[xIndex][yIndex] = TileDesignerLayout.imageA[selectedTile];
       
       System.out.println("SELECTED PANEL: " + selectedTile + " \n");
       System.out.println("\n MOUSE COORDINATES CLICKED ARE -->" + xIndex + " " + yIndex + "\n");
       
       this.repaint();  //show new grid
     }
  }

  @Override
  public void paintComponent(Graphics g) //Implementing paint component
  {  
    //draw gif array elements/gifs on the rectangles
    System.out.println("Now execute paint componenet to draw the shape"); // tells user we are in paint
    super.paintComponent(g); // call to base constructor
    
    // Edit/Change color of grid
    setBackground(Color.LIGHT_GRAY);
    
    gridWidth = gridCols*squareSide; // Calculate total width of grid
    gridHeight = gridRows*squareSide; // Calculate total height of grid
    
    int panelWidth = this.getWidth(); // Obtains width of selected image/gif
    int panelHeight = this.getHeight(); // Obtains height of selected image/gif
    
    startX = (panelWidth-gridWidth)/2;  // get middle spot to draw grid based horizontally
    startY = (panelHeight-gridHeight)/2;  // get middle spot to draw grid based vertically
  

   //Drawing empty grid of 5*5 with an inner outer loop
   for(int row = 0; row < gridRows; row++)
   {
       for(int col = 0; col < gridCols; col++)
       {
              g.drawRect(startX+(squareSide*row), startY+(squareSide*col), squareSide, squareSide);
       }
   } // end drawing rectangle grid
   
 
   //copy gif image array over to the drawing grid with inner outer loop
   for(int row = 0; row < gridRows; row++)
   {
       for (int col = 0; col < gridCols; col++)
       {
           // This copys the gif onto the selected grid
           g.drawImage(gif_2dArray[row][col], startX+(squareSide*row), startY+(squareSide*col), this);
       }
   } // end copy image to grid
   

  }

    @Override
    public void mousePressed(MouseEvent me) // Activates when mouse button is pressed
    {
        System.out.println("mouse pressed");
    }

    @Override
    public void mouseReleased(MouseEvent me) // Activates when mouse button is released
    {
        System.out.println("mouse released");
    }

    @Override
    public void mouseEntered(MouseEvent me) // Activates when mouse enters the middle panel
    {
        System.out.println("mouse entered: ");
    }

    @Override
    public void mouseExited(MouseEvent me)  // Activates when mouse exits the middle panel
    {
        System.out.println("mouse exited: ");
    }
  
} // END CLASS