<!--
Group: Undergrad 3
filename: enterinfo.php
Desc: Where the customer is prompted to enter their information before being handed off to the credit card check.
-->
<html>
<body>

<?php

#connection stuff

#Form for putting in customer information
echo '<form name ="custinfo" id="custinfo" action="cccheck.php" method="post">';
echo '<h3>Enter information</h3>';
echo '<label>Name: </label>';
echo '<input type="text" name="custname" id="custname" />';
echo '<br><label>Credit Card Number: </label>';
echo '<input type="text" name="crednum" id="crednum" />';
echo '<br><label>Expiration date:       &ensp;     &ensp;  &ensp;  </label>';
echo '<input type="text" name="cardexp" id="cardexp"/>';
echo '<br><label>(TEMP) Amount: </label>';
echo '<input type="text" name="amnt" id="amnt" />';
echo '<br><label>(TEMP) Vendor ID: </label>';
echo '<input type="text" name="vid" id="vid" />';
echo '<br><label>(TEMP) Transaction ID: </label>';
echo '<input type="text" name="tid" id="tid" />';
echo '<br><input type="submit" name="submit" value="Submit"><br>';
echo '</form>';

?>  

</body>
</html>