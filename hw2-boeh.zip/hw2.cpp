//*********************************************************************
// CLASS:     CSCI 480-1                                              *
// PROGRAM:   Assignment 2                                            *
// AUTHOR:    Mitch Boehning                                          *
// Z-NUM:     z1751490                                                *
// DUE DATE:  03/02/2017                                              *
//                                                                    *
// PURPOSE:   1. Obtain info from /proc/sys/kernal & uname and print  *
//               the information neatly.                              *
//                                                                    *
//            2. Using getenv() to get PATH values and then print     *
//               the path entries.                                    *
//                                                                    *
//            3. Set up fork() commands and create 3 children, while  *
//               showing each of them running.                        *
//                                                                    *
// EXECUTION: ./hw2.exe                                               *
//                                                                    *
// NOTES:                                                             *
//                                                                    *
//*********************************************************************

#include <sys/utsname.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <string>
#include <sstream>

using namespace std;

int main()
{
  cout << unitbuf << endl; //unbuffer the ouput

  struct utsname sysinfo;
  char const* tmp = getenv("PATH"); // temp storage for PATH
  uname(&sysinfo);
  int entry_num;
  int string_length;
  int total_length;
  int pid;  // used for first child
  int pid2; // used for middle child
  int pid3; // used for granchild
  ostringstream oss;

  // Used to store info from /proc/sys/kernel
  std::string cppstar;
  std::string ostype;
  std::string hostname;
  std::string osrelease;
  std::string version;
  std::string temp_info;

  // Store path variables
  std::string temp_string;
  std::string pathString;
  std::string rest_of_string;

  //Initialize ints
  entry_num = 0;
  string_length = 0;
  total_length = 0;

  // Stream in file ostype
  ifstream myfile("/proc/sys/kernel/ostype");
  if(myfile.fail())
  {
    cout << "Failed to open file." << endl;
    return 1;
  }

  // While not eof
  while(true)
  {
    getline(myfile, cppstar);
    if(myfile.eof())
    {
      break;
    }

  ostype = cppstar;

  } //end while

  // Close file
  myfile.close();

  // Stream in file hostname
  ifstream myfile2("/proc/sys/kernel/hostname");
  if(myfile2.fail())
  {
    cout << "Failed to open file: hostname" << endl;
    return 1;
  }

  // While not eof
  while(true)
  {
    getline(myfile2, cppstar);
    if(myfile2.eof())
    {
      break;
    }

    hostname = cppstar;

  } //end while

  // Close file
  myfile2.close();

  // Stream in file osrelease
  ifstream myfile3("/proc/sys/kernel/osrelease");
  if(myfile3.fail())
  {
    cout << "Failed to open file: osrelease" << endl;
    return 1;
  }

  // While not eof
  while(true)
  {
    getline(myfile3, cppstar);
    if(myfile3.eof())
    {
      break;
    }

  osrelease = cppstar;

  } //end while

  // Close file
  myfile3.close();

  // Stream in file version
  ifstream myfile4("/proc/sys/kernel/version");
  if(myfile4.fail())
  {
    cout << "Failed to open file - version." << endl;
    return 1;
  }

  // While not eof
  while(true)
  {
    getline(myfile4, cppstar);
    if(myfile4.eof())
    {
      break;
    }

    version = cppstar;
  } // end while

  version.resize(13);

  // Close file
  myfile4.close();

  //  *********************   PART B   ***********************************
  // Convert PATH into a string
  if(tmp == NULL)
  {
    std::cout << "No path found! \n";
  } else
    {
     std::string pathString(tmp);

     std::cout << "Your PATH is: " << pathString << "\n";

     std::cout << endl;

     std::cout << "String Entry" << setw(50) << "Byte Length" << endl;

     // Break Path down into seperate entries
     while(pathString.find_last_of(":") != pathString.find_first_of(":"))
     {
       std::size_t pos = pathString.find_first_of(":");

       // trim Path into seperate entry
       if(pos != std::string::npos)
       {
         rest_of_string = pathString.substr(pos + 1); // trim off first entry

         temp_string = pathString.substr(0,pos); // first string
       }

      pathString = rest_of_string; // make trimmed path the new PATH

      entry_num++; // increment number of entries

      string_length = temp_string.length() - 1; // find length of individual entry

      total_length += string_length; // increment total length of string

      std::cout.width(45); std::cout << std::left << temp_string << std::right
                                     << setw(10) << string_length << endl;

    } // endwhile


//    std::string second_last_string;
//    std::string last_string;

    // Find final ":" in PATH
//    std::cout << "Rest of Path: " << pathString << endl;

//    std::size_t pos = pathString.find(":");

//    if(pos!= std::string::npos)
//    {
//     second_last_string = pathString.substr(pos + 1);

//     last_string = pathString.substr(0,pos);
//    }
//   std::cout << "LOOK" << endl;
//    std::cout << second_last_string << endl;
//    std::cout << last_string << endl;

    std::cout << endl; // blank line

  }// end else if


  // **************************** OUTPUT **************************************

  std::cout << endl;
  std::cout << "Total number of entries: " << entry_num++ << endl;
  std::cout << "Total number of bytes: " << total_length << endl;

  std::cout << endl;
  std::cout << "Field" << setw(20) << "File data" << setw(20)
            << "API data" << endl;

  std::cout << "Ostype" << setw(15) << ostype << setw(21)
            << sysinfo.sysname << endl;
  std::cout << "Hostname" << setw(14) << hostname << setw(21)
            << sysinfo.nodename << endl;
  std::cout << "Osrelease" << setw(21) << osrelease << setw(21)
            << sysinfo.release << endl;
  std::cout << "Version" << setw(22) << version << setw(51)
            << sysinfo.version << endl;
  std::cout << "Machine" << setw(36) << sysinfo.machine << endl;
  std::cout << endl;


  // ***************************** PART C ************************************
  // Reset before each use
  oss.clear();
  oss.str("");

  // fork another process - first child
  pid = fork();

  // Check for error
  if(pid < 0)
  {
    cout << "Fork Failed" << endl;
    exit(-1);
  }
  else if (pid == 0)                                            // Child 1
  {
    oss << "Child: My PID is " << getpid() << "\n";
    oss << "My parent is " << getppid() << "\n";

    std::cout << oss.str() << endl;

    // reset
    oss.clear();
    oss.str("");

    return 0;
  }                                                       // end child1
  else                                                    // back to parent
  {
    pid2 = fork(); // create Second child

    if(pid2 == 0)                                         // Middle child
    {
      pid3 = fork(); // create grandchild

      if(pid3 == 0)                                        // Grandchild1
      {
        oss << "Child: My PID is " << getpid() << "\n";
        oss << "My parent is " << getppid() << "\n";

        std::cout << oss.str() << endl;

        // reset
        oss.clear();
        oss.str("");

        return 0;
      }                                                   // end Grandchild

      oss << "Middle: My PID is " << getpid() << "\n";
      oss << "My parent PID is " << getppid() << "\n";
      oss << "My child PID is " << pid3 << "\n";
      oss << "\n";

      std::cout << oss.str() << endl;

      // reset oss
      oss.clear();
      oss.str("");

      sleep(3);

      oss << "Middle " << getpid() << " is awake.\n";
      oss << "\n";
      oss << "Child " << pid3 << " is awake.\n";
      oss << "\n";
      oss << "Child " << pid << " is awake.\n";
      oss << "\n";

      std::cout << oss.str() << endl;

      // reset
      oss.clear();
      oss.str("");

      return 0;
    }                                                        // end Child 2
                                                             // Back in Parent
   oss << "Parent: My PID is " << getpid() << "\n";
   oss << "My parent is " << getppid() << "\n";
   oss << "My children are " << pid << " and " << pid2 << "\n";

   std::cout << oss.str() << endl;

   // reset oss
   oss.clear();
   oss.str("");

   oss << "Parent: Issuing command: /bin/ps -f --ppid " << getppid() << ", "
       << getpid() << ", " << pid << ", " << pid2 << "\n";

   std::cout << oss.str() << endl;

   // reset oss
   oss.clear();
   oss.str("");

   oss << "/bin/ps -f --ppid " << getppid() << "," << getpid() << "," << pid2;
   system(oss.str().c_str());

   std::cout << endl; // blank line

   // reset oss
   oss.clear();
   oss.str("");

   int returnStatus; // Used to determine if children are done
   waitpid(pid2, &returnStatus,0);

   if(returnStatus == 0)
   {
     oss << "Parent: All processes finished.\n";
     std::cout << oss.str() << endl;

     // reset oss
     oss.clear();
     oss.str("");
   }

  return 0;

  } // end parent

  return 0;

} // end main
