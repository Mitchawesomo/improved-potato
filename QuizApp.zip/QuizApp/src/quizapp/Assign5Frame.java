package quizapp;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.JFrame;

/**
 *
 * @author Mitch
 * z1751490
 * CSCI 470 LEON
 * Assignment 5:  Timed Self-Practice Quiz
 * Due Date: December 4th
 * 
 * Purpose:  Sets up the frame
 */

public class Assign5Frame extends JFrame
{
    public static void main(String[] args)
    {
        createAndShowGUI(); // call constructor
    }


    public static void createAndShowGUI()
    {        
        Assign5Frame pdg1 = new Assign5Frame(); //Calls Constructor to create GUI
        
        pdg1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Frame closes when app stops
        pdg1.setName("Quiz App");
        pdg1.setSize(500, 500);
        
        // Display the window
        pdg1.setVisible(true);
    }

    
    public Assign5Frame()
    {
        super("Mitch's Quiz App");
        
        // call QuizApp to create GUI
        QuizApp quizApp1 = new QuizApp(); // call constructor, builds GUI
        
        setLayout(new BorderLayout());
        
        add(quizApp1, BorderLayout.CENTER);
    }
   
} // Ends ASSIGN5FRAME
