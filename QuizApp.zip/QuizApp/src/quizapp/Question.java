package quizapp;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.JFrame;

/**
 *
 * @author Mitch
 * z1751490
 * CSCI 470 LEON
 * Due Date: December 7th, 2016
 * 
 * Purpose: Question.java is responsible for getting the answers and score for each question,
 *          as well as determining if studentAnswer is correct
 */
abstract class Question
{
  public int score = 0; //for grading
  
  public final static int FONT_SIZE = 24;

  //below we have a pointers to the question and answer for this particular question

  protected Object questionPtr = null; //pointer to some question “object”
                                       //object may be type “string” or type image, image has question on it

  private String answerPtr; //pointer to string object, all answers are type string
 
  // empty Constructor  
  public Question() {}
     
  // Poly Constructor
  public Question(String AnswerIn) 
    {
       this.answerPtr =  AnswerIn; //bring in pointer to string object which has the string answer for all questions
       
       System.out.println("IN CONSTRUCTOR: answerPtr: " + answerPtr + " AnswerIn: " + AnswerIn + " \n");
    }
     
  public abstract void draw(Graphics g, Dimension d);
     
  public void judgeAnswer(String studentAnswer)
  {
      System.out.println("studentAnswer: " + studentAnswer + " answerPtr: " + answerPtr);
      
      if(studentAnswer.equalsIgnoreCase(answerPtr))
      {
          System.out.println("add 1 to score correct");
          
          score += 1;
      }
      else
      {
          System.out.println("WRONG! Set score to 0");
          
          score = 0;
      }
  }

  public Object getQuestion()
  {
    return questionPtr;
  }

  public String getAnswer()
  {
    return (String) answerPtr;
  }

  public int getScore()
  {
    return score;
  }
} // ENDS QUESTION
