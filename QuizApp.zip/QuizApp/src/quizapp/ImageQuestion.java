package quizapp;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.ImageObserver;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.JFrame;

/**
 *
 * @author Mitch
 * z1751490
 * CSCI 470 LEON
 * Due Date: December 7th, 2016
 * 
 * Purpose:  ImageQuestion.java sets up the Image onto the question panel.
 */
class ImageQuestion extends Question
{
  private final ImageObserver observer;
     
  //constructor
  public ImageQuestion(String questionIn, String answerIn, ImageObserver observer)
  {
     super(answerIn); // answer is string, inQuestion is string ".jpg"
        
     this.observer = observer;  //needed to find the image when we draw it

     //get the jpeg out of toolkit..inQuestion is what was in quiz file ,example-  “buildingquestion.jpg”
     Image myImage1 = Toolkit.getDefaultToolkit().createImage(questionIn);
     
     questionPtr = (Object) myImage1;
                                                                                                                               //type image is here
   }
     
   @Override //Override for subclass Image Question
   public void draw(Graphics g, Dimension d)
   {
     int width, height, x, y;
     
     System.out.println("()IN DRAW of images for a question with image");
     System.out.println("questionPtr: " + questionPtr);
     
     Image myImage1 = (Image) questionPtr; // cast down for more fuctions

     //draw the question on graphics
     width = myImage1.getWidth(null); //get h and w of image
     height = myImage1.getHeight(null);
          
     x = d.width/2 - width/2;
     y = d.height/2 - height/2;
          
     g.drawImage(myImage1, x, y, observer);
   }
} // ENDS IMAGE QUESTION