<!--
Group: Undergrad 3
filename: editBracketsStart.php
Description: Showcases the selected order.  Admin then can decide to fullfill or not.
-->
<html>
<head>
	<title>Select</title>
<style>
.footer { 
	position: fixed; 
	bottom: 0; 
	}
.stroke2
	{
	color: white;
	text-shadow:
		-1px -1px 0 #000,
		1px -1px 0 #000,
		-1px 1px 0 #000,
		1px 1px 0 #000;
	}
</style>

</head>

<?php
//
//script to login into legacy database and display content
//
$hostname = "students";	//name of server
$username = "z1772281";	//username
$password = "1995May15";	//password
$db = "z1772281";	//name of database

//connecting to database
$conn = @mysql_connect($hostname,$username,$password);
if (!$conn) {
	die("Could not connect: " . mysql_error());
}

//select database
$db_selected = mysql_select_db($db, $conn);

if (!$db_selected) {
	die ("Could not use: " . $db . mysql_error());
}



//selection query
$sql = "SELECT * FROM orderTable WHERE orderID = '$_POST[id]'";

$result = mysql_query($sql, $conn);
//checking for failure
if (!$result) {
	die("Could not execute sql: " . mysql_error());
}

//echoing table headers
echo "<table align=center width=100%>";
	echo "<tr bgcolor=#416baf class=stroke2>";
	echo "<th align=left>Order Number</th>";
	echo "<th align=left>Status</th>";
	echo "<th align=left>Price</th>";
	echo "<th align=left>Address</th>";
	echo "</tr>";

// Loop that displays orders by variables accordingly
while($order=mysql_fetch_assoc($result)) {
	echo "<tr>";
	echo "<td align=left>".$order[orderID]."</td> ";
	echo "<td align=left>".$order[status]."</td> ";
	echo "<td align=left>".$order[orderPrice]."</td> ";
	echo "<td align=left>".$order[address]."</td> ";
	echo "</tr>";

}

echo "</table>";

echo "<form align=center method=post action=fulfillEnd.php>
	<input type=submit value=Fulfill>
	<input type=hidden name=fulfill value=1>
	<input type=hidden name=ID value='$_POST[id]'>
	</form>";

?>

</body>
</html>