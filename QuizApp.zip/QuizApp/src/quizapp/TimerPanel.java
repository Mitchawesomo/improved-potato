package quizapp;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.JFrame;
import javax.swing.Timer;
import java.time.LocalTime;

/**
 *
 * @author Mitch
 * z1751490
 * CSCI 470 LEON
 * Due Date: December 7th, 2016
 * 
 * Purpose:  TimerPanel.java is responsible for starting/stopping the timer during the quiz
 */
public class TimerPanel implements ActionListener
{   
    int delay = 1000; // Storage has the 1 second delay
    
    private int countTime;
    
    private int seconds;
    
    QuizApp QA = null;
      
    private final Timer timer1;

    TimerPanel(QuizApp qApp)
    {   
       timer1 = new Timer(delay, this); // Action performed is called every second when timer is started
       
       this.QA = qApp;
    }
    
    public void startTimer(int duration)
    {
        // Set textField in timer to x number of seconds
        String timeString = QA.durationTF.getText();
        
        seconds = Integer.valueOf(timeString);
        
        timer1.start();
        
        countTime = seconds * 60;
    }
    
    @Override
    public void actionPerformed(ActionEvent e)
    {
        // decrement count
        //System.out.println("Seconds: " + countTime);
        
        countTime--;
        
        if(countTime <= 0)
        {
            stopQuiz();
        }
        else
        {
          // convert seconds to string and show in time field with set text
          QA.timerTF.setText(String.valueOf(countTime));
        }
    }
    
    // Stops the quiz by calling stoptimer() and relaying back to QuizApp
    public void stopQuiz()
    {
        stopTimer();
        
        QA.endQuiz();
    }
    
    // Will be called from QuizApp, stops the timer
    public void stopTimer()
    {
        timer1.stop(); // stops the method in java timer object
        
        QA.timerTF.setText(" "); // clear timer to blank
    }
} // END TIMER PANEL
