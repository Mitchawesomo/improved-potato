<!--
Group: Undergrad 3
filename: cccheck.html
Desc: This checks the credit card to make sure it is valid.
Note: We didn't know how to check the result for invalid cards/failed authorizations.
-->
<?php header("refresh:0;url=autoPartsHome.html");?>
<?php
$url = 'http://blitz.cs.niu.edu/CreditCard/'; // url to check card, sent through an array
$data = array(
	'vendor' => $_POST["vid"], // Generated Vendor ID
	'trans' => $_POST["tid"],  // Generated Transaction ID
	'cc' => $_POST["crednum"], // Customer inputted Credit Card Number
	'name' => $_POST["custname"], // Customer's Name
	'exp' => $_POST["cardexp"],  // Credit Card Expiration Date
	'amount' => $_POST["amnt"]); // Order's total price

// Array is encoded into JSON    
$options = array(
    'http' => array(
        'header' => array(
             'Content-type: application/json'
           , 'Accept: application/json'),
	'method' => 'POST',
        'content'=> json_encode($data)
    )
);

$context  = stream_context_create($options);
$result = file_get_contents($url, false, $context);
echo($result);


//script to login into legacy database and display content
//
$hostname = "students";	//name of server
$username = "z1772281";	//username
$password = "1995May15";	//password
$db = "z1772281";	//name of database

//connecting to database
$conn = @mysql_connect($hostname,$username,$password);
if (!$conn) {
	die("Could not connect: " . mysql_error());
}

//select database
$db_selected = mysql_select_db($db, $conn);

if (!$db_selected) {
	die ("Could not use: " . $db . mysql_error());
}

// Variables for to be inserted into table
$tID = intval($_POST['tid']);
$orderPrice = floatval($_POST['amnt']);
$address = $_POST['address'];

$sql = "INSERT INTO orderTable (orderID, status, orderPrice, address) VALUES ('".$tID."', 0, '".$orderPrice."', '".$address."');";

$result = mysql_query($sql, $conn);
//checking for failure
if (!$result) {
	die("Could not execute sql: " . mysql_error());
}

?>