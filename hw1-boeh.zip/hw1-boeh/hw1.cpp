//************************************************************************
// CLASS:     CSCI 480-1                                                 *
// PROGRAM:   Assignment 1 - Reading Virtual/Proc files                  *
// AUTHOR:    Mitch Boehning                                             *
// Z NUM:     z1751490                                                   *
// DUE DATE:  02/14/17                                                   *
//                                                                       *
// PURPOSE:   Main program reads in two different files, storing the     *
//            lines in a string, and then giving output to answer        *
//            questions about /proc/cpuinfo and /proc/uptime.            *
//                                                                       *
// EXECUTION: ./hw1                                                      *
//                                                                       *
// NOTES:                                                                *
//                                                                       *
//************************************************************************

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <vector>
#include <stdlib.h>
#include <sstream>
#include <cmath>

#include "Processor.h"

using namespace std;

int main()
{
  const char FILE_NAME[] = "/proc/cpuinfo";
  int line_count;
  int char_count;
  int proc_count;
  int pcpu_count;

  // Used to determine ratio between address sizes
  float ratio;
  float two = 2.0;

  string buffer;

  // Initialize vector for Processor info
  vector <Processor*> core;
  vector <Processor*>::iterator it;

  // Strings for storing needed lines
  string psString = " ";
  string vsString = " ";
  string fpuString = " ";
  string l2cString = " ";

  // KEYS FOR FINDING INFORMATION
  std::string key1 ("processor");     // used to find total cores
  std::string key2 ("core id");       // used to find physical CPUs
  std::string key3 ("physical id");   // used to find physical ids

  std::string key4 ("address sizes");  //used to find physcial address size
  std::string key5 ("physical,");      //used to find virtual address size
  std::string key6 ("fpu");           //used to find if contains fpu
  std::string key7 ("cache size");    // used to find how big is level 2 cache

  // Initialize counters
  line_count = 0;
  char_count = 0;
  proc_count = 0;
  pcpu_count = 0;

  // Open file
  ifstream myfile1("/proc/cpuinfo");

  if(myfile1.fail())
  {
    cout << "cpuinfo failed to open" << endl;
    return 1;
  }

  while(true)
  {
    getline(myfile1, buffer);
    if(myfile1.eof())
    {
      cout << "Reached end of cpuinfo file." << endl;
      break;
    }

    line_count++; // increment line count

    // Increment character count
    char_count += buffer.length() + 1;

    //  Determine number of Processors
    size_t proc_index = buffer.find(key1);

    if(proc_index != string::npos)
    {
      proc_count++;
    }


    // Determine number of Physical CPUs
    size_t phyCPU = buffer.rfind(key2);

    if(phyCPU != string::npos)
    {
      pcpu_count++;
    }

     // Find line of physical address
     size_t ps_input = buffer.find(key4);

     // Determine if address actually found
     if(ps_input != string::npos)
     {
       // Find where ": " (colon) is on the line
       size_t ps_index = buffer.rfind(":");

       // Trim line so just physical address remains
       psString = buffer.substr(ps_index + 2,  buffer.length() - ps_index - 28);
     }

     // Find line of virtual address
     size_t vs_input = buffer.find(key4);

     // Determine if address actually found
     if(vs_input != string::npos)
     {
       // Find were "," (comma) is on the line
       size_t vs_index = buffer.rfind(",");

       // Trim lne so just physical address remains
       vsString = buffer.substr(vs_index + 2, buffer.length() - 10 - vs_index);
     }

     // Determine if Processor has floating point unit
     size_t fpu_flags = buffer.find("flags");

     // Determine if fpu actually found
     if(fpu_flags != string::npos)
     {

     }else
      {
        size_t fpu_input = buffer.find(key6);

        if(fpu_input != string::npos)
        {
          // Find where ":" (colon) is on the line
          size_t fpu_index = buffer.rfind(":");

          // Trim line so just "yes or no" is on the line
          fpuString = buffer.substr(fpu_index + 2, buffer.length() - fpu_index);
        }
      }//end else

     // Determine if size of L2 cache
     size_t l2c_input = buffer.find(key7);

     // Determine if L2 Cache actually found
     if(l2c_input != string::npos)
     {
       // Find where ":" (colon) is on the line
       size_t l2c_index = buffer.rfind(":");

       // Trim line so just size of cache
       l2cString = buffer.substr(l2c_index + 1, buffer.length() - l2c_index - 4);
     }

   } // end while

     // Begin storing values into vector
     for(int i = 0; i < 1; i++)
     {
       // New up a new Processor
       Processor* proc_ptr = new Processor();

       // Set values for first Processor
       if(i == 0)
       {
	 proc_ptr->set_PhySize(psString);
         proc_ptr->set_VirtSize(vsString);
         proc_ptr->set_fpu(fpuString);
         proc_ptr->set_L2Cache(l2cString);
       }

        core.push_back(proc_ptr);
     }// end for loop

  // Initialize size ratio
  std::string::size_type sy; //alia of size_t

  int Pratio = atoi(psString.c_str()); // convert to int
  int Vratio = atoi(vsString.c_str()); // convert to int

  ratio = (float)Vratio-Pratio; // cast difference to a float temp

  float final_ratio = pow(two,ratio); // 2^(ratio)

  int byte_cache = atoi(l2cString.c_str()); // convert to int

  byte_cache = byte_cache * 1000; // changee bytes

  string UPString; // used to obtain uptime string
  string seconds;  // used to cotain just seconds active
  int days, hours, minutes;

  // Initalize variables
  seconds = " ";
  days = 0;
  hours = 0;
  minutes = 0;

  // Open Uptime file
  ifstream myfile2("/proc/uptime");
  if(myfile2.fail())
  {
    cout << "Failed to open Uptime file...." << endl;
    return 1;
  }

  pcpu_count = pcpu_count / 2;

  getline(myfile2, UPString);

  // close uptime file
  myfile2.close();

  // Shorten string to just get seconds active
  size_t str_index = UPString.find(" ");

  if(str_index != string::npos && UPString.length() >= 2)
  {
    seconds = UPString.substr(str_index - 10, UPString.length() - str_index - 2);
  }

  std::string::size_type sz; // alia of size_t

  int secs = atoi(seconds.c_str()); // convert to double

  minutes = secs / 60; // find number of days
  hours = minutes / 60;
  days = hours / 24;

  // OUTPUT SECTION
  cout << "FILE READ: " << FILE_NAME << endl;

  cout << "We have read " << line_count << " " <<
          (line_count == 1 ? "record. " : "records. ") <<  endl;

  cout << "There have been a total of " << char_count << " characters. " << endl;

  cout << "To count number of records: wc -l cpuinfo" << endl;
  cout << "To count number of characters: wc -m cpuinfo" << endl;
  cout << endl;

  cout << "Total number of Processors: " << proc_count << endl;
  cout << "Total number of Physical CPUs: " << pcpu_count << endl;
  cout << "Yes, Processors 0 & 4, 1 & 5, 2 & 6, and then 3 & 7 share L2 cache"
       << endl;
  cout << endl;

  // Print values from Vector class
  for (it = core.begin(); it != core.end(); it++)
  {
    cout << "The physical address size is: " << (*it)->get_PhySize() << endl;
    cout << "The virtual address size is: " << (*it)->get_VirtSize() << endl;
    cout << "The size ratio between the two is: " << final_ratio <<  endl;
    cout << "Does the processor have a fpu? " << (*it)->get_fpu() << endl;
    cout << "The size of the L2 Cache in KB is: " << (*it)->get_L2Cache()
         <<  " kilobytes." << endl;
    cout << "The size of the L2 Cache in bytes is: " << byte_cache
         << " bytes." << endl;
  }

  cout << endl;
  cout << "This Computer has been up for " << seconds << " seconds." << endl;

  cout << "This computer has been up for " << int(days) << " days, "
      << int(hours%24) << " hours, " << int(minutes%60)
      << " minutes, and 4.3 seconds. " << endl;

  return 0;

} // end Main()
