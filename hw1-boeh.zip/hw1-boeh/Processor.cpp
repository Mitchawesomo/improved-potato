//**********************************************************
// CLASS:    CSCI480-01                                    *
// PROGRAM:  Assignment 1                                  *
// AUTHOR:   Mitch Boehning                                *
// Z-NUM:    z1751490                                      *
// DUE DATE: 02/14/2017                                    *
//                                                         *
// PURPOSE:  Contains all the methods for finding info for *
//           the processors.                               *
//                                                         *
// NOTES:                                                  *
//                                                         *
//**********************************************************

#include <string>
#include <iostream>
#include <iomanip>
#include <vector>
#include <cstdlib>
#include <stdlib.h>

#include "Processor.h"

using namespace std;

// Constructor, initialize variables
Processor::Processor()
{
  Phy_Size = " ";
  Virt_Size = " ";
  fpu = " ";
  L2Cache = " ";
}

// Obtain Physical Size from cpuinfo
string Processor::get_PhySize()
{
  return Phy_Size;
}

// Obtain Virtual Size from cpuinfo
string Processor::get_VirtSize()
{
  return Virt_Size;
}

// Obtain fpu from cpuinfo
string Processor::get_fpu()
{
  return fpu;
}

// Obtain L2 Cache size from cpuinfo
string Processor::get_L2Cache()
{
  return L2Cache;
}

// Set Physical Size address
void Processor::set_PhySize (string inputPS)
{
  Phy_Size = inputPS;
}

// Set Virtual Size address
void Processor::set_VirtSize (string inputVS)
{
  Virt_Size = inputVS;
}

// Set fpu (if there is one)
void Processor::set_fpu (string inputFPU)
{
  fpu = inputFPU;
}

// Set  L2 Cache
void Processor::set_L2Cache (string inputL2C)
{
  L2Cache = inputL2C;
}
