package quizapp;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

/**
 *
 * @author Mitch
 * z1751490
 * CSCI 470 LEON
 * Due Date: December 7th, 2016
 * 
 * Purpose:  TestQuestion.java draws the text question onto the question panel.
 */
public class TestQuestion extends Question
{   
    public TestQuestion(String questionIn, String AnswerIn)
    {
      super(AnswerIn); //  obtains answer for question
      
      questionPtr = (Object) questionIn;  //  fill in question pointer in base class,inquestion is type string
                                          // questionPtr is type object
   }
     
 @Override
 public void draw(Graphics g, Dimension d)
   {
     System.out.println("in TestQuestion Draw()\nquestionPtr: " + questionPtr);  
       
     int width, x, y;
     
     Object textObj = questionPtr; // current question is stored under textObj
 
     FontMetrics fm = g.getFontMetrics(new Font("Arial", Font.PLAIN, 12)); // Font for question
     
      width = fm.stringWidth((String) textObj); // determine how long width of question will be
      
      System.out.println("textObj: " + textObj);
      
      x = d.width/2 - width/2;
      y = d.height/2;
      
      String mystringQuestion = (String) textObj;  //cast from obj to string
      
      g.drawString(mystringQuestion,x,y); //draw the string question 
   } 
} // END TEXT QUESTION