package quizapp;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.JFrame;
import java.lang.InterruptedException;

/**
 *
 * @author Mitch
 * z1751490
 * CSCI 470 LEON
 * Assignment 5:  Timed Self-Practice Quiz
 * Due Date: December 4th
 * 
 * Purpose:  This class organizes the QuestionPanel. Starts the quiz, checks answers, starts/stops both threads
 */
public class QuestionPanel extends JPanel implements Runnable
  {
    private static ArrayList<Question> questionAL = new ArrayList();  //arraylist to hold type questions
  
    QuizApp parent = null;
    Thread runner = null;
    Dimension d;
    Boolean quizoverFlag;
    Boolean timeUpFlag;
    int currentquestion = -1;
    String questionIn;
    String AnswerIn;
    int score = 0;
    
    // Constructor
    QuestionPanel(QuizApp inParent)
      {
         this.parent = inParent;  //bring in a pointer to parent object (quiz app)
      }
    
    // Initiates the Start of the Quiz
    public void startQuiz()
      {
         runner = new Thread(this);
         runner.start();  //we start the run() method
      }

    @Override
    public void run()
      {
         quizoverFlag = false;
         timeUpFlag = false;
         
         readQuestionFile(); //prepare questions and arraylist
         
         System.out.println("Passed readQuestionFile()");

         currentquestion++; //current question = 0
         
         System.out.println("PASSED currentquestion: " + currentquestion + " \n");

         repaint(); //this will display first question in the list by calling paintcomp.

         //while (timer not up   and   not quizover) //spin loop till one of these items gets us out
         while(quizoverFlag == false && timeUpFlag == false)
         {
             try
             {
                //System.out.println("\nquizoverFlag: " + quizoverFlag + "\ntimeUpFlag: " + timeUpFlag);
                 
                 // sleeps for a second
                 runner.sleep(1000);
                  
             }
             catch(InterruptedException exc)
             {
                 System.out.println("timer/quizOver error!!\n");
             }
         } // endwhile
         
         // Stopped by QuizoverFlag
         // If time is not up
         if(timeUpFlag != false)
         {   
             System.out.println("TIME IS UP\n");
             // make time be up
             quizoverFlag = true;
             
             System.out.println("quizover: " + quizoverFlag + "\ntimeupFlag: " + timeUpFlag);
             
             repaint();
             
             // restart to -1
             currentquestion = -1;
             
             // Start threading at beginning
             runner = null;
             
             //restart score
             score = 0;
             
             // clear array for next quiz
             questionAL.clear();
         }

       } // ENDS RUN()
    
    @Override
    public void paintComponent(Graphics g) // Implementing paint component
      {
        System.out.println("PAINT TRIGGERED");
        super.paintComponent(g);
        
        //on startup of app don’t do anything
        if (currentquestion == -1)
        {
            return; // Wait for user
        }

        //if quiz over
        if(quizoverFlag == true)
        {
            
           //quiz is over-make a text question with “quiz over message”,compute score, and call draw
           computeScore();
            
           questionIn = "QUIZ IS OVER!  YOUR SCORE IS " + score;
           //AnswerIn =  Integer.toString(score);
           
           System.out.println(score);
            
           Question quizOver = (new TestQuestion(questionIn, null));
           
           quizOver.draw(g,d); // call draw (text)
           
           parent.clearAnswer();
           
           parent.endFinal(); //end the quiz
           
           // restart to -1
           currentquestion = -1;
             
           // Start threading at beginning
           runner = null;
           
           // restart score for next quiz
           score = 0;
           
           // clear AL for next quiz
           questionAL.clear();
           
           System.out.println("yes we made it here");
        }
        else
        {
           Question oneQuestion = (Question) questionAL.get(currentquestion); // Cast question out of AL

           d = getSize(); // get dimension of Question
           
           oneQuestion.draw(g,d); //call the draw method of this question (image or text)
                                                                                                                                             
           parent.clearAnswer(); //clears the old answer in text box, and then we wait for user to give us answer
        }
      } // Ends Paint()
          
    public void processAnswer(String answer)
      {
        //     called from QuizApp after user types answer and hits submit
        Question oneQuestion = (Question) questionAL.get(currentquestion); //get the q
        
        oneQuestion.judgeAnswer(answer); //judge answer is () in the question,sets int inquestion to 0 or 1
                             
        currentquestion++; //go to next q in array list
        
        System.out.println("currentquestion: " + currentquestion);
                
        if(currentquestion == 3)
        {
          System.out.println("currentquestion equals size of AL");

          quizoverFlag = true;
          
          repaint(); // now the quiz is over
        }
        
        repaint(); //fires paint even so we draw next question

        
       } // End proccessAnswer

    // Go through AL summing up scores
    public void computeScore()
    {
        for(int x = 0; x < questionAL.size(); x++)
        {
            // used to count the score
            score++;
            
            System.out.println("computeScore = " + score);
        }
    }
    
    // Goes through the txt file, properly newing up the correct question that is read in
    public void readQuestionFile()
       {  
         try
         {
           // Find file with scanner  
           File file1 = new File("quiz.txt");  
           
           Scanner fileScanner = new Scanner(file1);  
           
           // Once Scanner finds something
           while(fileScanner.hasNext())
           {
              // Make it the next question
              questionIn = fileScanner.nextLine(); // store first thing read in into questionIn
              
              AnswerIn = fileScanner.nextLine(); // store second thing read in into AnswerIn
              
              // message showing what was found
              System.out.println("Something found in file? " + fileScanner.hasNext());         
              
             // we have q and answer, assign q to text or image sub type 
             // If questionIn is an image, send it to ImageQuestion and add to AL
             if(questionIn.endsWith(".jpg") || questionIn.endsWith(".gif"))
             {
                 System.out.println("QI: " + questionIn + "\n AI: " + AnswerIn);
                 
                 questionAL.add(new ImageQuestion(questionIn, AnswerIn, this)); // add ImgQuestion to AL
                 
                 System.out.println("in the if image");
                
             }
             else // Otherwise, send question and answer to TestQuestion
             {   
                 System.out.println("QI: " + questionIn + "\n AI: " + AnswerIn);
                 
                 questionAL.add(new TestQuestion(questionIn, AnswerIn)); // add TextQuestion to AL
                 
                 System.out.println("in the if text");
             }
           } // end while
         }
         catch(FileNotFoundException e)
         {
             System.out.println("\nquiz.txt was not found exting program");
             System.exit(21);
         } // end catch

       } // End readQuestionFile

} // ENDS QUESTION PANEL
