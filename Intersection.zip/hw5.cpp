//********************************************************************
// CLASS:      CSCI 480-1
// PROGRAM:    Assignment 5
// AUTHOR:     Mitch Boehning
// Z-NUM:      z1751490
// DUE DATE:   05/04/2017
//
// PURPOSE:    While using shared memory and semaphores, create a
//             scenario of the intersection Lincoln and Annie
//             Glidden.  Divide the intersection into four, and
//             have each car cross accordingly.
//
// EXECUTION:  ./hw5.exe
//
// NOTES:
//
//********************************************************************

#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>

#include <iostream>
#include <iomanip>
#include <sstream>
#include <cstdlib>
#include <cstring>

using namespace std;

void worker(int i, void * args);

struct Sems {
  sem_t sem_array[5];
  };

int main(int argc, char *argv[])
{
  int i; // counter
  int id;
  pid_t pids[4]; // 4 children processes
  int ret; // return code

  const int const_0 = 0;

  Sems* MySems; // Pointer to struct

  // no buffering
  cout << unitbuf;

  // Allocate segment of shared memory
  id = shmget(IPC_PRIVATE, sizeof(Sems), (S_IRUSR|S_IWUSR));

  // Check to see shared memory created
  if(id == -1)
  {
    cout << "Failed to create shared memory segment" << endl;
    return 1;
  }

  // Attach shared memory to pointer of struct
  MySems = (Sems*)shmat(id, NULL, 0);

  // Check if it was sucessfully attached
  if(MySems == (void *)-1)
  {
    cout << "Failed to attach memory segment" << endl;
    return 1;
  }

  // Show the attachment
  cout << "Got shared memory with id " << id << endl;

  cout << "Attached to shared memory at " << MySems << endl;

  // Initialize Semaphores
  for(i = 0; i < 5; i++)
  {
    ret = sem_init(&(MySems -> sem_array[i]), 1, 1);

    // Check for initialization
    if(ret == -1)
    {
      cout << "Failed to initialize semaphore" << endl;
    }
    else
    {
      cout << "Initialized semaphore # " << i << " to 1 " << endl;
    }
  } // End Initialization

  cout << endl; // space

  // Fork 4 Children for each lane of traffic
  for(i = 0; i < 4; i++)
  {
    ret = fork();

    // Check for failure
    if (ret < 0)
    {
      cout << "Failed to create process" << endl;
      return 1;
    }
    else
    {
      pids[i] = ret;

      if(pids[i] == 0)                                 // In Child
      {
        worker(i, MySems); // Send lane to be processed

        exit(0); // Once all 3 cars are processed
      }
    }// End else
  } // End fork loop
                                                      // Now in Parent
  for(i = 0; i < 4; i++)
  {
    wait(const_0);
  }

  // Detach shared memory
  ret = shmdt((void *)MySems);

  // Check for detach
  if(ret == -1)
  {
    cout << "Unable to detach shared memory" << endl;
    return 1;
  }

  // Remove shared memory segment
  ret = shmctl(id, IPC_RMID, NULL);

  // Check for removal
  if(ret == -1)
  {
    cout << "Unable to free the shared memory" << endl;
    return 1;
  }

  return 0;
} // End main


void worker(int i, void * args)
{
  // Return code
  int ret;  // lane 1
  int ret2; // lane 2
  int ret3; // lane 3
  int ret4; // lane 4

  // Car counter
  int j = 1; // Lane 1
  int k = 1; // Lane 2
  int l = 1; // Lane 3
  int m = 1; // Lane 4

  // Semaphore positions in struct
  const int NE_0 = 0;
  const int NW_1 = 1;
  const int SW_2 = 2;
  const int SE_3 = 3;
  const int COUT_4 = 4;

  // Pointer to struct
  Sems* MySems;

  // no buffering
  cout << unitbuf;

  // Obtain argument (pointer to stuct)
  MySems = (Sems*)args;

  // Lane 1 process                                          LANE 1
  if(i == 0)
  {
    // Grab cout semaphore                                   Grab cout
    ret = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display Semaphore 1                                   First lock
    cout << "Starting process for street " << i << ": Lincoln Hwy West" << endl;

    cout << endl;

    // Release cout                                          Post cout
    ret = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

   // 3 cars
   for(j = 1; j < 4; j++)
   {

    // Grab first semaphore                                  Grab sem 1
    ret = sem_wait(&(MySems->sem_array[SE_3]));

    // Check if lock was actually grabbed
    while(ret == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: SE" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret = sem_wait(&(MySems->sem_array[SE_3]));
    }

    // Grab cout semaphore                                   Grab cout
    ret = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display Semaphore 1                                   First lock
    cout << "On Lincoln Hwy West, car " << j << " has obtained lock for SE" << endl;

    cout << endl;

    // Release cout                                          Post cout
    ret = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

    // Grab second semaphore                                 Grab 2nd sem
    ret = sem_wait(&(MySems->sem_array[SW_2]));

    // Check if lock was actually grabbed
    while(ret == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: SW" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret = sem_wait(&(MySems->sem_array[SW_2]));
    }

    // Grab cout semaphore                                   Grab cout
    ret = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display                                           Both locks and cross
    cout << "On Lincoln Hwy West, car " << j << " has obtained lock for SW" << endl;

    cout << "On Lincoln Hwy West, car " << j << " has obtained both locks" << endl;

    cout << "On Lincoln Hwy West, car " << j << " has crossed" << endl;

    cout << endl;

    // Release cout                                       post cout
    ret = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

    // Release Semaphore 1                                Post sem 1
    ret = sem_post(&(MySems->sem_array[SE_3]));

    // Check
    if(ret == -1)
    {
      cout << "Failed to unlock SE" << endl;
    }

    // Release Semaphore 2                                Post sem 2
    ret = sem_post(&(MySems->sem_array[SW_2]));

    // Check
    if(ret == -1)
    {
      cout << "Failed to unlock SW" << endl;
    }

    // Grab cout semaphore                                Grab cout
    ret = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display unlock                                     Display unlock
    cout << "On Lincoln Hwy West, car " << j << " has unlocked SE" << endl;

    cout << "On Lincoln Hwy West, car " << j << " has unlocked SW" << endl;

    cout << "On Lincoln Hwy West, car " << j << " has unlocked both locks" << endl;

    // Release cout                                       Post cout
    ret = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

   } // End for loop

    // Remainder section
    return;

  } // End Lane 1

  // Lane 2 process                                     LANE 2
  if(i == 1)
  {
    // Grab cout semaphore                                   Grab cout
    ret = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display Semaphore 1                                   First lock
    cout << "Starting process for street " << i << ": Annie Glidden North" << endl;

    cout << endl;

    // Release cout                                          Post cout
    ret = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

   // 3 cars
   for(k = 1; k < 4; k++)
   {
    // Grab first semaphore                             Grab Sem 1
    ret2 = sem_wait(&(MySems->sem_array[NW_1]));

    // Check if lock was actually grabbed
    while(ret2 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: NW" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret2 = sem_wait(&(MySems->sem_array[NW_1]));
    }

    // Grab cout semaphore                              Grab cout
    ret2 = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret2 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret2 = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display Semaphore 1                              Display sem 1
    cout << "On Annie Glidden North, car " << k << " has obtained lock for NW" << endl;

    cout << endl;

    // Release cout                                    Post cout
    ret2 = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret2 == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

    // Grab second semaphore                           Grab sem 2
    ret2 = sem_wait(&(MySems->sem_array[SW_2]));

    // Check if lock was actually grabbed
    while(ret2 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: SW" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret2 = sem_wait(&(MySems->sem_array[SW_2]));
    }

    // Grab cout semaphore                              Grab cout
    ret2 = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret2 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret2 = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display                                          Display and cross
    cout << "On Annie Glidden North, car " << k << " has obtained lock for SW" << endl;

    cout << "On Annie Glidden North, car " << k << " has obtained both locks" << endl;

    cout << "On Annie Glidden North, car " << k << " has crossed" << endl;

    cout << endl;

    // Release cout                                     Post cout
    ret2 = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret2 == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

    // Release Semaphore 1                             Post sem 1
    ret2 = sem_post(&(MySems->sem_array[NW_1]));

    // Check
    if(ret2 == -1)
    {
      cout << "Failed to unlock NW" << endl;
    }

    // Release Semaphore 2                             Post sem 2
    ret2 = sem_post(&(MySems->sem_array[SW_2]));

    // Check
    if(ret2 == -1)
    {
      cout << "Failed to unlock SW" << endl;
    }

    // Grab cout semaphore                            Grab cout
    ret2 = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret2 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret2 = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display unlock                               Display unlock and cross
    cout << "On Annie Glidden North, car " << k << " has unlocked NW" << endl;

    cout << "On Annie Glidden North, car " << k << " has unlocked SW" << endl;

    cout << "On Annie Glidden North, car " << k << " has unlocked both locks" << endl;

    // Release cout                                 Post cout
    ret2 = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret2 == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

   } // End for loop

   // Remainder section
   return;

  } // End Lane 2

  // Lane 3 process                                       LANE 3
  if(i == 2)
  {
    // Grab cout semaphore                               Grab cout
    ret3 = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret3 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret3 = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display Semaphore 1                              Display sem 1
    cout << "Starting process for street " << i << ": Lincoln Hwy East" << endl;

    cout << endl;

    // Release cout                                      Post sem 1
    ret3 = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret3 == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

   for(l = 1; l < 4; l++)
   {
    // Grab first semaphore                             Grab Sem 1
    ret2 = sem_wait(&(MySems->sem_array[NW_1]));

    // Check if lock was actually grabbed
    while(ret2 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: NW" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret2 = sem_wait(&(MySems->sem_array[NW_1]));
    }

    // Grab cout semaphore                              Grab cout
    ret2 = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret2 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret2 = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display Semaphore 1                              Display sem 1
    cout << "On Annie Glidden North, car " << k << " has obtained lock for NW" << endl;

    cout << endl;

    // Release cout                                    Post cout
    ret2 = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret2 == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

    // Grab second semaphore                             Grab sem 2
    ret3 = sem_wait(&(MySems->sem_array[NE_0]));

    // Check if lock was actually grabbed
    while(ret3 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: NE" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret3 = sem_wait(&(MySems->sem_array[NE_0]));
    }

    // Grab cout semaphore                                Grab cout
    ret3 = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret3 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret3 = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display                                          Display lock and cross
    cout << "On Lincoln Hwy East, car " << l << " has obtained lock for NE" << endl;

    cout << "On Lincoln Hwy East, car " << l << " has obtained both locks" << endl;

    cout << "On Lincoln Hwy East, car " << l << " has crossed" << endl;

    cout << endl;

    // Release cout                                     Post cout
    ret3 = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret3 == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

    // Release Semaphore 1                              Post sem 1
    ret3 = sem_post(&(MySems->sem_array[NW_1]));

    // Check
    if(ret3 == -1)
    {
      cout << "Failed to unlock NW" << endl;
    }

    // Release Semaphore 2                              Post sem 2
    ret3 = sem_post(&(MySems->sem_array[NE_0]));

    // Check
    if(ret3 == -1)
    {
      cout << "Failed to unlock NE" << endl;
    }

    // Grab cout semaphore                              Grab cout
    ret3 = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret3 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret3 = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display unlock                                Display unlock
    cout << "On Lincoln Hwy East, car " << l << " has unlocked NW" << endl;

    cout << "On Lincoln Hwy East, car " << l << " has unlocked NE" << endl;

    cout << "On Lincoln Hwy East, car " << l << " has unlocked both locks" << endl;

    // Release cout                                  Post cout
    ret3 = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret3 == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

   } // end foor loop

   // Remainder section
   return;

  } // End Lane 3

  // Lane 4 process                                       LANE 4
  if(i == 3)
  {
    // Grab cout semaphore                                   Grab cout
    ret = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display Semaphore 1                                   First lock
    cout << "Starting process for street " << i << " : Annie Glidden South" << endl;

    cout << endl;

    // Release cout                                          Post cout
    ret = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

    // Grab first semaphore                              Grab sem 1
    ret4 = sem_wait(&(MySems->sem_array[SE_3]));

    // Check if lock was actually grabbed
    while(ret4 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: SE" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret4 = sem_wait(&(MySems->sem_array[SE_3]));
    }

   // 3 cars
   for(m = 1; m < 4; m++)
   {
    // Grab cout semaphore                               Grab cout
    ret4 = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret4 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret4 = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display Semaphore 1                               Display sem 1
    cout << "On Annie Glidden South, car " << m << " has obtained lock for SE" << endl;

    cout << endl;

    // Release cout
    ret4 = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret4 == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

    // Grab second semaphore                            Grab sem 2
    ret4 = sem_wait(&(MySems->sem_array[NE_0]));

    // Check if lock was actually grabbed
    while(ret4 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: NE" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret4 = sem_wait(&(MySems->sem_array[NE_0]));
    }

    // Grab cout semaphore                             Grab cout
    ret4 = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret4 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret4 = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display                                        Display locks and corss
    cout << "On Annie Glidden South, car " << m << " has obtained lock for NE" << endl;

    cout << "On Annie Glidden South, car " << m << " has obtained both locks" << endl;

    cout << "On Annie Glidden South, car " << m << " has crossed" << endl;

    cout << endl;

    // Release cout                                   Post cout
    ret4 = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret4 == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

    // Release Semaphore 1                            Post sem 1
    ret4 = sem_post(&(MySems->sem_array[SE_3]));

    // Check
    if(ret4 == -1)
    {
      cout << "Failed to unlock SE" << endl;
    }

    // Release Semaphore 2                            Post sem 2
    ret4 = sem_post(&(MySems->sem_array[NE_0]));

    // Check
    if(ret4 == -1)
    {
      cout << "Failed to unlock NE" << endl;
    }

    // Grab cout semaphore                              Grab cout
    ret4 = sem_wait(&(MySems->sem_array[COUT_4]));

    // Check
    while(ret4 == -1)
    {
      if(errno != EINTR)
      {
        cout << "Failed to lock semaphore: COUT" << endl;
        return;
      }

      // Keep attempting to grab semaphore
      ret4 = sem_wait(&(MySems->sem_array[COUT_4]));
    }

    // Display unlock                                Display unlock
    cout << "On Annie Glidden South, car " << m << " has unlocked SE" << endl;

    cout << "On Annie Glidden South, car " << m << " has unlocked NE" << endl;

    cout << "On Annie Glidden South, car " << m << " has unlocked both locks" << endl;

    // Release cout                                    Post cout
    ret4 = sem_post(&(MySems->sem_array[COUT_4]));

    // Check
    if(ret4 == -1)
    {
      cout << "Failed to unlock COUT" << endl;
    }

   } // End for loop

   // Remainder section
   return;

  } // End of Lane 4

 // Return to main
 return;
}
