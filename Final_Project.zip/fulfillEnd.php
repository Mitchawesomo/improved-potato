<!--
Group: Undergrad 3
filename: editBracketsStart.php
Desc: Where the order is fulfilled and added to the table.
-->
<html>
<head>
	<title>Select</title>
<style>
.footer { 
	position: fixed; 
	bottom: 0; 
	}
.stroke2
	{
	color: white;
	text-shadow:
		-1px -1px 0 #000,
		1px -1px 0 #000,
		-1px 1px 0 #000,
		1px 1px 0 #000;
	}
</style>

</head>

<?php
//
//script to login into legacy database and display content
//
$hostname = "students";	//name of server
$username = "z1772281";	//username
$password = "1995May15";	//password
$db = "z1772281";	//name of database

//connecting to database
$conn = @mysql_connect($hostname,$username,$password);
if (!$conn) {
	die("Could not connect: " . mysql_error());
}

//select database
$db_selected = mysql_select_db($db, $conn);

if (!$db_selected) {
	die ("Could not use: " . $db . mysql_error());
}

//update query
$sql = "update orderTable set status = 1 where orderID = '$_POST[ID]'";

mysql_query($sql, $conn);

//selection query
$sql = "SELECT * FROM orderTable WHERE orderID = '$_POST[ID]'";

$result = mysql_query($sql, $conn);
//checking for failure
if (!$result) {
	die("Could not execute sql: " . mysql_error());
}

//echoing table headers
echo "<table align=center width=100%>";
	echo "<tr bgcolor=#416baf class=stroke2>";
	echo "<th align=left>Order Number</th>";
	echo "<th align=left>Status</th>";
	echo "<th align=left>Price</th>";
	echo "<th align=left>Address</th>";
	echo "</tr>";

// Loop that displays orders by variables accordingly
while($order=mysql_fetch_assoc($result)) {
	echo "<tr>";
	echo "<td align=left>".$order[orderID]."</td> ";
	echo "<td align=left>".$order[status]."</td> ";
	echo "<td align=left>".$order[orderPrice]."</td> ";
	echo "<td align=left>".$order[address]."</td> ";
	echo "</tr>";

}

echo "</table>";

echo "<br><p align=center>Status Updated</p>";

?>

</body>