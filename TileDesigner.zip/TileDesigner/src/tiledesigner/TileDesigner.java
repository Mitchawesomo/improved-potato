package tiledesigner;

import java.awt.*;
import javax.swing.JFrame;
/**
 *
 * @author Mitch
 * z1751490
 * CSCI 470 LEON
 * Assignment 4: Tile Design
 * Due Date: November 9th, 2016
 * 
 * Purpose: This class contains all the methods when interacting with the tile Designer.
 */
public class TileDesigner extends JFrame
{      
  public static void main(String[] args)
  {
    createAndShowGUI(); // Call method to create the Gui
  }
  
  public static void createAndShowGUI()
  {
    TileDesigner pdg1 = new TileDesigner(); // CALLS CONSTRUCTOR
    pdg1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Frame closes when App stops
    pdg1.setName("Tile Designer"); // name JFrame
    pdg1.setSize(400,400); // set size of JFrame
    
    // Display the window
    pdg1.setVisible(true);
  }    
  
  // Constructor that calls TileDesignerLayout
  public TileDesigner()
  {
    super("Mitch's Tile Designer");
    
   // call a class to design the GUI 
    TileDesignerLayout tiledesign = new TileDesignerLayout(); // CALLS CONSTRUCTOR, builds the GUI
    
    setLayout(new BorderLayout());
    add(tiledesign,BorderLayout.CENTER);
  }
  
}