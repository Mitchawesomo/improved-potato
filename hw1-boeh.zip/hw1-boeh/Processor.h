#ifndef PROCESSOR_INCLUDED
#define PROCESSOR_INCLUDED

//***********************************************************
// CLASS:    CSCI 480-1                                     *
// PROGRAM:  Assignment 1                                   *
// AUTHOR:   Mitch Boehning                                 *
// Z-NUM:    z1751490                                       *
// DUE DATE: 02/14/2017                                     *
//                                                          *
// PURPOSE:  Contains all public and private methods for    *
//           each individual processor.                     *
//                                                          *
// NOTES:                                                   *
//                                                          *
//***********************************************************

#include <string>
#include <iomanip>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <stdlib.h>

using namespace std;

class Processor
{
 public:
        // Empty Constructor
        Processor();

	string get_PhySize();
	void set_PhySize(string inputPS);

	string get_VirtSize();
	void set_VirtSize(string inputVS);

	string get_fpu();
	void  set_fpu(string inputFPU);

	string get_L2Cache();
	void set_L2Cache(string inputL2C);

 private:
	string Phy_Size;
	string Virt_Size;
	string fpu;
	string L2Cache;

}; // end class

#endif
