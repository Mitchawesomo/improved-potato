<!--
Group: Undergrad 3
filename: addorder.html
Desc: This adds the order to the ordertable that we use to flag orders that need to be shipped.
-->
<html>
<head>
	<title>Browsing</title>
<style>
.footer { 
	position: fixed; 
	bottom: 0; 
	}
.stroke2
	{
	color: white;
	text-shadow:
		-1px -1px 0 #000,
		1px -1px 0 #000,
		-1px 1px 0 #000,
		1px 1px 0 #000;
	}
</style>

</head>

<body align="center">
<form name="Orders" id="Orders" action="addorder.php" method="post">
<?php
//connecting to internal parts database
$partshostname = "courses";	//name of server
$partsusername = "z1772281";	//username
$partspassword = "1995May15";	//password
$partsdb = "z1772281";	//name of database
//
$partsconn = @mysql_connect($partshostname,$partsusername,$partspassword); 
if (!$partsconn) {
	die("Could not connect: " . mysql_error());
}
//select database
$db_selected = mysql_select_db($partsdb, $partsconn);


if (!$db_selected) {
	die ("Could not use: " . $db . mysql_error());
}

foreach ($_POST as $key => $value) {
  foreach($value as $k => $v)
  {
	  if(!empty($v)){//checks and only prints orders if they are not empty. Only add to database
					//in this if statement
		echo "<tr>";
		echo "<th align=left>Part Number:	</th>";
		echo "<td align=left>".++$k."</td> ";  //prints product number
		echo "<th align=left>Order Quantity:	</th>";
		echo "<td align=left>".$v."</td> ";   //prints quantity
		echo "<th align=left>Part Price:	</th>";
        $sql = "select price from internaldb where number = ".$k."";
        $result = mysql_query($sql, $partsconn);
        $price = mysql_result($result, 0);
		echo "<td align=left>".$price."</td> ";   //prints price        
		echo '<hr />';
        $total = $total + ($price * $v); // Configure Total price
        
	  }
		
		echo "</tr>";

  }
        echo "Total: ".$total."."; // Print Total price of parts
} 
?> 
</form>

<?php

# Creates two unique IDs for Vendor and Transaction
$uniqueID = mt_rand(100000, 999999);
$uniqueID2 = mt_rand(100000, 999999);


#connection stuff

#Form for putting in customer information
echo '<form name ="custinfo" id="custinfo" action="cccheck.php" method="post">';
echo '<h3>Enter information</h3>';
echo '<label>Name: </label>';
echo '<input type="text" name="custname" id="custname" />';
echo '<br><label>Credit Card Number: </label>';
echo '<input type="text" name="crednum" id="crednum" />';
echo '<br><label>Expiration date:       &ensp;     &ensp;  &ensp;  </label>';
echo '<input type="text" name="cardexp" id="cardexp"/>';
echo '<br><label>Address: </label>';
echo '<input type="text" name="address" id="address"/>';
echo '<br><label>(TEMP) Amount: </label>';
echo '<input type="text" name="amnt" id="amnt" value="'.$total.'" readonly/>';
echo '<br><label>(TEMP) Vendor ID: </label>';
echo '<input type="text" name="vid" id="vid" value="'.$uniqueID2.'" readonly />';
echo '<br><label>(TEMP) Transaction ID: </label>';
echo '<input type="text" name="tid" id="tid" value="'.$uniqueID.'" readonly />';
echo '<br><input type="submit" name="submit" value="Submit"><br>';
echo '</form>';

?>
</body>
</html>