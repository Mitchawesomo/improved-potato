package pdgamegui;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.JFrame;
/**
 *
 * @author Mitch
 * z1751490
 * CSCI 470 LEON
 * Assignment 3: Prisoner's Dilemma with GUI
 * Due Date: October 18th, 2016
 * 
 * Purpose: This class contains the layout for the application, as well as
 * implementing the game, asking the user questions and retrieving answers.
 */
public class PDGameGUI extends JFrame implements ActionListener,ListSelectionListener
{
   // set up JFrame
   JFrame frame1 = new JFrame("Mitch's Prisoner Dilemma");
   
   GameStat gameStatInfo = new GameStat();
   
   // Set up Hashmap to save all statistics
   HashMap<String, GameStat> stats = new HashMap<>();
   
   // Generate random number for random number of rounds
   Random rand = new Random();
   
   int randomNum = rand.nextInt((10 - 1) + 1) + 1;
   
   // Variable for num of rounds
   private int numClicks = 0;
    
   //instance variables for PDGameGUI,  are up here so all methods below can access them
   // Used to store each game session
   private final DefaultListModel<String> listModel = new DefaultListModel<>();
   
   // List of finished games
   private final JList<String> finishedGamesList; //jlist will be put in the listmodel
   
   // Text field displaying statistics from the game
   private final JTextField roundsPlayedTF = new JTextField(10);
   private final JTextField computerStrategyTF = new JTextField(10);
   private final JTextField playerSentenceTF = new JTextField(10);
   private final JTextField computerSentenceTF = new JTextField(10);
   private final JTextField winnerTF = new JTextField(10);
   
   // label for the combo box containing all the possible computer strategies
   private final JLabel computerStrategyCBL = new JLabel("Computer Strategy-Combo Box");
   
   // Labels for all of the Game Statistics
   private final JLabel roundsPlayedL = new JLabel("Rounds Played");
   private final JLabel computerStrategyL = new JLabel("Computer Strategy");
   private final JLabel playerSentenceL = new JLabel("Player Sentence");
   private final JLabel computerSentenceL = new JLabel("Computer Sentence");
   private final JLabel winnerL = new JLabel("Winner");
   
   // Colors for labels, buttons, frame, etc
   // higher colors = lighter
   Color c1 = new Color(211, 211, 55);
   Color c2 = new Color(150, 150, 150);
   
   // Initialize all three buttons
   private final JButton startB = new JButton("Start New Game");
   private final JButton betrayB = new JButton("Testify");
   private final JButton silentB = new JButton("Remain Silent");
   
   // Combobox for list of possible options for computer strategy
   private final JComboBox<Object> computerStrategyCB;
   
   // computerStrategy decision
   private int computerStrategy = 1;
   
   // Label next to Betray or silent
   private final JLabel decisionL = new JLabel("Your decision this round?");
             
   // Text area to display all the text throughout the game
   private final JTextArea gameResultsTA = new JTextArea(15, 35);
   
   private PDGame currentPDGame = null;
   private String gameStartTime = null;
   //private final HashMap<String, gameStatptr> stats = new HashMap<>();

   
     public static void main(String[] args) 
     {
          createAndShowGUI();
     }
     
   public static void createAndShowGUI() {
      // Create and set up the window.
      PDGameGUI pdg1 = new PDGameGUI(); //call constructor below to set the window to user
      pdg1.addListeners();     //method will add listeners to buttons
      pdg1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      // Display the window and pack together all the panels, etc
      pdg1.pack();
      pdg1.setVisible(true);      
   }

  
//CONSTRUCTOR WHERE YOU BUILD THE SWING INTERFACE
   public PDGameGUI() 
   {   
      super("Mitch's Prisoner's Dilemma");
      currentPDGame = new PDGame();
      
      setLayout(new BorderLayout());
      
      // LEFT AND RIGHT SIDE PANELS
      
      // Left panel
      JPanel panelLeft = new JPanel(new BorderLayout());
      
      // set panel to color c1
      panelLeft.setBackground(c1);
      
      add(panelLeft, BorderLayout.WEST); //add to frame
      
      // Right panel
      JPanel panelRight = new JPanel(new BorderLayout());
      
      panelRight.setBackground(c2); // set right panel to color
      
      add(panelRight, BorderLayout.EAST); // add a right side panel
      
      
      // LEFT PANEL BEGINS HERE,  GAMES LIST AND THEIR STATS
      
      // Set up top left "list"      
      finishedGamesList = new JList<>(listModel);
            
      finishedGamesList.setFont(new Font("SansSerif", Font.BOLD, 24));
      finishedGamesList.setVisibleRowCount(10);
      finishedGamesList.setFixedCellWidth(350);
      finishedGamesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      
      // add GamesList to scroll pane
      JScrollPane scroll1 = new JScrollPane(finishedGamesList);
       
      scroll1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
       
      panelLeft.add(scroll1, BorderLayout.NORTH);
      
      // set up bottom left Textfield to display all the statistics
      JPanel panelResults = new JPanel(new BorderLayout()); // set up frame
      
      panelResults.setBackground(c1); // set color
      
      panelResults.setLayout(new GridLayout(5,2)); // sets grid to 5 rows, 2 columns
      
      // add all the labels and text fields to the grid
      panelResults.add(roundsPlayedL);
      panelResults.add(roundsPlayedTF);
      panelResults.add(computerStrategyL);
      panelResults.add(computerStrategyTF);
      panelResults.add(playerSentenceL);
      panelResults.add(playerSentenceTF);
      panelResults.add(computerSentenceL);
      panelResults.add(computerSentenceTF);
      panelResults.add(winnerL);
      panelResults.add(winnerTF);
      
      panelLeft.add(panelResults, BorderLayout.SOUTH); // add to frame

      //        RIGHT SIDE     RIGHT SIDE    RIGHT SIDE   RIGHT SIDE
      //COMBO BOX ON RIGHT      
      JPanel panelStart = new JPanel(new BorderLayout()); // Panel for all buttons and labels
      
      panelStart.setLayout(new GridLayout(2,1)); // sets to 2 rows, 1 column
      
      panelRight.add(panelStart, BorderLayout.NORTH); // add to frame
      
      // Make sure text area is NOT editable
      gameResultsTA.setEditable(false);
      
       // add TA to scroll pane
       JScrollPane scroll2 = new JScrollPane(gameResultsTA);
       
       scroll2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
      
      panelRight.add(scroll2, BorderLayout.SOUTH); // add scroll pane to bottom left of right panel
      
      // FLOW LAYOUT PANELS FOR RIGHT SIDE BEGIN HERE
      // Panel for combo box and start new game
      JPanel topRightPanel = new JPanel();
      
      topRightPanel.setLayout(new FlowLayout()); // default layout for new panel
      
      topRightPanel.setBackground(Color.CYAN); // change color
      
      // add "Computer Strategy" label
      topRightPanel.add(computerStrategyCBL);
      
      // retrieves possible strategies for combo box
      Object[] strategyArray = currentPDGame.getStrategies().toArray();//convert AL to array
      computerStrategyCB = new JComboBox<>(strategyArray); // makes array into combo box
      computerStrategyCB.setEditable(false); // combo box cannot be edited
      computerStrategyCB.setSelectedIndex(0); // if no strategy selected, first strategy is used
      topRightPanel.add(computerStrategyCB); // add combo box to panel
      
      // Add start button to top east panel5
      topRightPanel.add(startB);
      // Change the buttons color
      startB.setForeground(c1);
      startB.setBackground(c2);
      
      panelStart.add(topRightPanel, BorderLayout.NORTH); // add combo box and start game to top right panel
            
      // Panel for betray or remain silent
      JPanel bottomRightPanel = new JPanel();
      
      bottomRightPanel.setLayout(new FlowLayout());
      
      bottomRightPanel.setBackground(Color.ORANGE);
      
      // add label to panel, asking to pick a button
      bottomRightPanel.add(decisionL);
      
      // Add silent button to top east panel5
      bottomRightPanel.add(silentB);
      // Change the buttons color
      silentB.setForeground(Color.GREEN);
      silentB.setBackground(Color.YELLOW);
      
      // Add betray button to top east panel5
      bottomRightPanel.add(betrayB);
      // change the buttons color
      betrayB.setForeground(Color.RED);
      betrayB.setBackground(Color.BLUE);
        
      panelStart.add(bottomRightPanel, BorderLayout.SOUTH); // add betray or silent options to panel
      
      frame1.pack(); // Packs all the compoenents together
      
   } //end constructor
 

//hook up listeners to buttons so when button is clicked, the action listener does correct action
   public void addListeners() 
   {
       startB.addActionListener(this);
       silentB.addActionListener(this);
       betrayB.addActionListener(this);
       computerStrategyCB.addActionListener(this);
       finishedGamesList.addListSelectionListener(this);
  }

   @Override  //HANDLES WHT BUTTON WAS CLICKED and calls appropriate method
   public void actionPerformed(ActionEvent e)
   {
      // Starts up a game of Prisoner's Dilemma
      if (e.getSource() == startB)
      {
         startGame();
         
      }
      // If Silent button clicked, call cooperate and increment round by 1
      else if (e.getSource() == silentB)
      {
         cooperate();
         numClicks++;
      }
      // If Betray button clicked, call betray and increment round by 1
      else if (e.getSource() == betrayB)
      {
         betray();
         numClicks++;
      }
      // If a strategy in combobox clicked, save the selected strategy under computerStrategy
      else if (e.getSource() == computerStrategyCB)
      {
         computerStrategy = computerStrategyCB.getSelectedIndex() + 1;
      }
   }


   public void startGame() {
      
      // Starts up a new game
      currentPDGame = new PDGame();
      
      // Assigns picked strategy to computerStrategy
      currentPDGame.setStrategy(computerStrategy);
      
      // Saves the new game when the game was started in the hashmap
      gameStartTime = (new Date()).toString();
      stats.put(gameStartTime, currentPDGame.getStats());
      
      // Only Betray or Silent buttons are now enabled
      computerStrategyL.setEnabled(false);
      computerStrategyCB.setEnabled(false);
      startB.setEnabled(false);
      decisionL.setEnabled(true);
      silentB.setEnabled(true);
      betrayB.setEnabled(true);
      
      // Display beginning of game
      String beginning = "*** Prisoner's Dilemma***\n";
      gameResultsTA.append(beginning);

      
      // Send the user to ask whether they will betray or be silent
      promptPlayer();
   }
   
   // Asks user whether they want to betray or remain silent after clicking "start new game"
   public void promptPlayer()
   {
      String prompt = "\n1. Cooperate with your partner and remain silent.\n"
              + "2. Betray and testify against your partner.\n" + "\nWhat is your decision this round?\n";
              
      // Prompt player to make a decision Silent or Betray
      gameResultsTA.append(prompt);
      
   }

    private void betray()
    {
        // Send results to playRound
        currentPDGame.playRound(2);
        
        // Display results from that decision
        gameResultsTA.append(currentPDGame.getResults());
       
        // If 5th round, game ends
        if(numClicks < randomNum)
        {
            // Prompt player to choose again
            promptPlayer();
        }
        else
        {
            endGame();
            
            numClicks = 0;
            
        }
        
    }

    // Is called when user clicks on Silent button
    private void cooperate()
    {   
       // Send results to playRound
       currentPDGame.playRound(1);
        
       // Display results from that decision
       gameResultsTA.append(currentPDGame.getResults());
       
        // If 5th round, game ends
        if(numClicks < randomNum)
        {
            // Prompt player to choose again
            promptPlayer();
        }
        else
        {
            endGame();
            
            numClicks = 0;
        }
    }
    
   // Ends the game and shows results. Then stores results in game list
   public void endGame()
   {
       decisionL.setEnabled(false);
       this.silentB.setEnabled(false);
       betrayB.setEnabled(false);
       
       computerStrategyL.setEnabled(true);
       computerStrategyCB.setEnabled(true);
       startB.setEnabled(true);
       
       gameResultsTA.append("END OF ROUNDS, GAME OVER - GAME STATS:\n");
            
       gameResultsTA.append(currentPDGame.getScores()); // Get scores
     
       listModel.addElement(gameStartTime); // game time to upper left list model
   }
    
   //user has clicked on a finished game in upper left list box,
   //        show results from game
   @Override
   public void valueChanged(ListSelectionEvent e)
   {
       String searchKey;
       
      if (!finishedGamesList.isSelectionEmpty())
      { 
         searchKey = (String) finishedGamesList.getSelectedValue(); //get out time of game and look up in hash map
         gameStatInfo = stats.get(searchKey); // look it up in hash table
         
         roundsPlayedTF.setText(new Integer(gameStatInfo.roundsPlayed).toString());
         roundsPlayedTF.setFont( new Font("SansSerif", Font.BOLD, 18));
         
         computerStrategyTF.setText(new String(gameStatInfo.getCompStrat()));
         computerStrategyTF.setFont (new Font("SansSerif", Font.BOLD, 18));

         
         playerSentenceTF.setFont( new Font("SansSerif", Font.BOLD, 16));
         playerSentenceTF.setText(String.format("%d %s", gameStatInfo.playerYears, 
                 ((gameStatInfo.playerYears > 1) ? " years" : " year")));
         
         computerSentenceTF.setFont(new Font("SansSerif", Font.BOLD, 16));
         computerSentenceTF.setText(String.format("%d %s", gameStatInfo.computerYears,
                  ((gameStatInfo.computerYears > 1) ? " years" : " year")));
         
         winnerTF.setFont(new Font("SansSerif", Font.BOLD, 16));
         winnerTF.setText(new String(gameStatInfo.getWinner()));
         
       }
   }

    
} // end PDGAMEGUI

