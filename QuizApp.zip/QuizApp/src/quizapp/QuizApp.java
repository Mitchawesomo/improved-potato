package quizapp;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.JFrame;

/**
 *
 * @author Mitch
 * z1751490
 * CSCI 470 LEON
 * Assignment 5:  Timed Self-Practice Quiz
 * Due Date: December 4th
 * 
 * Purpose:  Once quiz started, user is asked 3 questions and is timed to complete them.
 *   This is the main class. The GUI is set up here.
 */
public class QuizApp extends JPanel implements ActionListener
{
  // sets up JFrame
  JFrame frame1 = new JFrame("Mitch's Quiz App");
  
  private final int duration = 0;
  
  // Text boxes for duration of quiz and answer area
  static final JTextField durationTF = new JTextField(20);
  private final JTextField answerTF = new JTextField(20);
  static final JTextField timerTF = new JTextField(3);
    
  // Labels to contain JTextField and their buttions
  private final JLabel durationL = new JLabel("Total Duration (mins)");
  private final JLabel answerL = new JLabel("Your answer:");
  
  // Buttons for start and submit
  private final JButton startB = new JButton("Start");
  private final JButton submitB = new JButton("Submit");

  TimerPanel timerPanel1 = new TimerPanel(this); //  pointer, the class Timer Panel is in timerpanel.java
                                              //passing to it a pointer to this (quizapp) object
                                              //because code there will call methods here

  QuestionPanel questionPanel = new QuestionPanel(this); // Pointer to QP object

  // Constructor builds Frame
  public QuizApp()
  { 
    setLayout(new BorderLayout(4,4));   //sets layout for the quizapp main panel
    
    setBorder(BorderFactory.createLineBorder(Color.GREEN)); // FRAME BORDER GREEN
    
    // START BUTTON PANEL LAYOUT
    JPanel startPanel = new JPanel(new BorderLayout(1, 5));
    
    startPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK)); // top panel border black
    
    // Add to Panel
    startPanel.add(durationL, BorderLayout.WEST);
    startPanel.add(durationTF, BorderLayout.CENTER);
    startPanel.add(startB, BorderLayout.EAST);
    
    JPanel topPanel = new JPanel(new BorderLayout(1,5)); // used to organize top
    
    topPanel.add(startPanel, BorderLayout.WEST); // Add to TopPanel
    
    add(topPanel, BorderLayout.NORTH); // Add to top of panel
    
    // timer Panel and TF
    JPanel timePanel = new JPanel();
    
    timerTF.setEditable(false); // timer is not editable
    
    timePanel.add(timerTF); // add timer to panel
    
    topPanel.add(timePanel, BorderLayout.EAST); // add panel to topPanel
    
    //topPanel.add(timerPanel1, BorderLayout.EAST);
    
    // PANEL FOR QUESTIONS
    
    JPanel testPanel = new JPanel(new BorderLayout(1,6)); // will be used for questions
    
    testPanel.add(questionPanel, BorderLayout.CENTER); // add panel to frame
    
    testPanel.setBorder(BorderFactory.createLineBorder(Color.BLUE));
    
    add(testPanel, BorderLayout.CENTER);
    
    // PANEL FOR ANSWERS
    
    JPanel answerPanel = new JPanel(new BorderLayout(1,4)); // used to for answers
    
    answerPanel.add(answerL, BorderLayout.WEST);
    answerPanel.add(answerTF, BorderLayout.CENTER);
    answerPanel.add(submitB, BorderLayout.EAST);
    
    JPanel bottomPanel = new JPanel(new BorderLayout(1,5)); // used to organize bottom
    
    bottomPanel.add(answerPanel); // add panel to bottom panel
    
    add(bottomPanel, BorderLayout.SOUTH); // add panel to frame
    
    addListeners();
    
    // Buttons cannot be used until quiz starts
    submitB.setEnabled(false);
    answerTF.setEnabled(false);
    
    frame1.pack(); // pack all components together
  }//end constructor    

  // clears the anwer text field (set it to spaces)
  public void clearAnswer()
  {
      answerTF.setText(" ");
  } 


  @Override // Handles which button was clicked, and calls appropriate method
  public void actionPerformed(ActionEvent e)
    {
        // If Start Button clicked, timers is started and then quiz is started
        if (e.getSource() == startB)
        {
            startB.setEnabled(false); // startB now disabled until end of quiz
            durationTF.setEnabled(false); // duration cannot be changed either
            submitB.setEnabled(true);
            answerTF.setEnabled(true);
            
            // Timer begins from calling startTimer
            timerPanel1.startTimer(duration);
                    
            // startQuiz is called from questionPanel
            questionPanel.startQuiz();
            
        }
        // If Submit Button is clicked, ProccessAnswer is called
        else if (e.getSource() == submitB)
        {
            questionPanel.processAnswer(answerTF.getText().trim());
        }
    } // end AcionPerformed

    // Hooks up Listeners to Buttons, so action Listener does correct action(s)
    final void addListeners() 
    {
        startB.addActionListener(this);
        submitB.addActionListener(this);   
    }
    
    // trigger timeUpFlag in QuestionPanel
    public void endQuiz()
    {   
       System.out.println("endQuiz() called!"); 
        
       questionPanel.timeUpFlag = true;
       
       startB.setEnabled(true); // can start another quiz
       durationTF.setEnabled(true); // can now change duration of quiz
    }
    
    // Allows user to restart quiz once they finish
    // Not called if Timer is up
    public void endFinal()
    {
       startB.setEnabled(true); // can start another quiz
       durationTF.setEnabled(true); // can now change duration of quiz
       submitB.setEnabled(false);
       answerTF.setEnabled(false);
       
       // Stop the timer
       timerPanel1.stopTimer();
    }
    
} // End QuizApp