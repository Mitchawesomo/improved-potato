package pdgamegui;

import java.util.*;

/**
 *
 * @author Mitch
 * z1751490
 * CSCI 470 LEON
 * Assignment 3: Prisoner's Dilemma with GUI
 * 
 * Purpose:  This class tracks both player's sentences as well as the round number.
 * 
 */
public class GameStat 
{
 int roundsPlayed = 0;
 int playerYears;
 int computerYears;
 int compStrat = 0;
  
 // empty Constructor
 GameStat()
 {
   
 }
 
 // Retrieves computer strategy from PDGame
 public void compStrategy(int cStrat)
 {     
  this.compStrat = cStrat;
 }
 
 // Takes selected comp Strategy and returns which strategy was used
 public String getCompStrat()
 {
     if(compStrat == 1)
     {
         return "Read From Input File";
     }
     else if(compStrat == 2)
     {
         return "Tit-For-Tat";
     }
     else if(compStrat == 3)
     {
         return "Tit-For-Two-Tats";
     }
     else
     {
         return "Random Choice";
     }
 }
 
 public void update(int player, int computer)
 {
     // Round is incremented by one
     roundsPlayed++;
     
     // Adds more years sentence for player
     this.playerYears += player;
     
     // Adds more years to sentence for computer
     this.computerYears += computer;
     
 }
 
 public String getWinner()
 {     
     // If player has more years, Computer wins
     if(playerYears > computerYears)
     {   
         return "Computer";
     }
     // If computer has more years, player wins
     else if(playerYears < computerYears)
     {
         return "Player";
     }
     // If both scores the same, tie game
     else
     {      
         return "Sorry! Tied game!";
     }
 } // end getWinner()

} // end GameStat


// Rounds Played = GameStat.roundsPlayed()
// Computer Strategy = GameStat.compStrat()
// Player Sentence = GameStat.playerYears
// Computer Sentence = GameStat.computerYears
// Winner = GameStat.getWinner()