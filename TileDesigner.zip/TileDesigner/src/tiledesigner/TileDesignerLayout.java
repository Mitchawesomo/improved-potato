package tiledesigner;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.JFrame;
/**
 *
 * @author Mitch
 * z1751490
 * CSCI 470 LEON
 * Assignment 4: Tile Design
 * Due Date: November 9th, 2016
 * 
 * Purpose: This class contains the layout for the Tile Designer.
 */
public class TileDesignerLayout extends JPanel implements ActionListener
{
  // set up JFrame
  JFrame frame1 = new JFrame("Mitch's Tile Designer");    
    
  // String array that stores the image names used by other classes
    // Static so that other objects can get at this with classes
  static final String[] imageStringNameA ={"pat1.gif","pat2.gif","pat3.gif","pat4.gif","pat5.gif"}; //holds names of patches

  static Image[] imageA = new Image[5];	 //image array to hold 5 images that are loaded

  TileCanvas centerPanel1ptr = new TileCanvas(); // This is center area

  JButton patch1btn,patch2btn,patch3btn,patch4btn,patch5btn = new JButton(); //all buttons….

  JButton resetButton = new JButton("Reset");

  // Constructor for class
  public TileDesignerLayout()
  {    
     // Load images for jtoolbar
     centerPanel1ptr.LoadImageArray();
     
     // Make the gui layout for what user sees
     setLayout(new BorderLayout());
 
     setBorder(BorderFactory.createLineBorder(Color.GREEN)); // change border of frame to green
     
     centerPanel1ptr.CreateMouseListener(); //Add listener to central panel							
     
     centerPanel1ptr.setBorder(BorderFactory.createLineBorder(Color.YELLOW)); // set middle panel border to yellow
     
     // clears gridline to start anew
     centerPanel1ptr.ResetGridTile(); //call methods in other class to set stuff up
     
     //Panel which will have reset button on it
     JPanel resetPanel = new JPanel();
     
     resetPanel.add(resetButton); // add reset button to panel
     
     add(resetPanel, BorderLayout.SOUTH); // add panel to frame


     JToolBar tileToolBar = new JToolBar(); //create a tool bar
     
     // Match all the patch gifs to a JButton
     patch1btn = new JButton(new ImageIcon(imageA[0]));
     patch2btn = new JButton(new ImageIcon(imageA[1]));
     patch3btn = new JButton(new ImageIcon(imageA[2]));
     patch4btn = new JButton(new ImageIcon(imageA[3]));
     patch5btn = new JButton(new ImageIcon(imageA[4]));
     
     // Add all the buttons to the JToolBar
     tileToolBar.add(patch1btn);
     tileToolBar.add(patch2btn);
     tileToolBar.add(patch3btn);
     tileToolBar.add(patch4btn);
     tileToolBar.add(patch5btn);
     
     // Add toolbar to frame
     add(tileToolBar,BorderLayout.NORTH);
     
     add(centerPanel1ptr, BorderLayout.CENTER); //Adding centerPanel to Frame.
	
     // set up buttons to be listeners in constructor
        patch1btn.addActionListener((ActionEvent) -> 
          {
            centerPanel1ptr.selectedTile = 0;
          });  //if patch button 1 is clicked,set tile variable to 0
        
        patch2btn.addActionListener((ActionEvent e) ->
          {
             centerPanel1ptr.selectedTile = 1;         
          }); // if patch button 2 is clicked, set tile variable to 1
        
        patch3btn.addActionListener((ActionEvent e) ->
        {
            centerPanel1ptr.selectedTile = 2;
        }); // If patch button 3 is clicked, set tile variable to 2
        
        patch4btn.addActionListener((ActionEvent e) ->
        {
           centerPanel1ptr.selectedTile = 3;           
        }); // If patch button 4 is clicked, set tile variable to 3
        
        patch5btn.addActionListener((ActionEvent e) ->
        {
           centerPanel1ptr.selectedTile = 4;
        }); // If patch button 5 is clicked; set tile variable to 4
        
        resetButton.addActionListener(this);
        
      frame1.pack(); // packs all components together
      
      System.out.println("Tile Designer Layout");
        
  }  // END CONSTRUCTOR

    @Override //HANDLES WHT BUTTON WAS CLICKED and changes SelectedTile to the selected one.
    public void actionPerformed(ActionEvent e)
    {
      // If patch 1 selected, patch is the selected design
      if (e.getSource() == patch1btn)
      {
          centerPanel1ptr.selectedTile = 0;
      }
      // If patch 2 selected, patch is the selected design
      else if (e.getSource() == patch2btn)
      {
          centerPanel1ptr.selectedTile = 1;
      }
      // If patch 3 selected, patch is the selected design
      else if (e.getSource() == patch3btn)
      {
          centerPanel1ptr.selectedTile = 2;
      }
      // If patch 4 selected, patch is the selected design
      else if (e.getSource() == patch4btn)
      {
          centerPanel1ptr.selectedTile = 3;
      }
      // If patch 5 selected, patch is the selected design
      else if (e.getSource() == patch5btn)
      {
          centerPanel1ptr.selectedTile = 4;
      }
      // If reset button is clicked, calls method to clear the grid square
      else if (e.getSource() == resetButton)
      {
          centerPanel1ptr.ResetGridTile();
          
          System.out.println("Reset Grid clicked\n");
      }
    }
 } // END CLASS
