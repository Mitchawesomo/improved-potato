<!--
Group: Undergrad 3
filename: displayParts.php
Desc: This is what the customer will see. It is the fulfill order use case.
-->
<html>
<head>
	<title>Browsing</title>
<style>
.footer { 
	position: fixed; 
	bottom: 0; 
	}
.stroke2
	{
	color: white;
	text-shadow:
		-1px -1px 0 #000,
		1px -1px 0 #000,
		-1px 1px 0 #000,
		1px 1px 0 #000;
	}
</style>

</head>

<body align="center">
<form name="Orders" id="Orders" action="addorder.php" method="post">
<?php
//
//script to login into legacy database and display content
//
$hostname = "blitz";	//name of server
$username = "student";	//username
$password = "student";	//password
$db = "csci467";	//name of database
//connecting to legacy database
//
//connecting to internal parts database
$partshostname = "courses";	//name of server
$partsusername = "z1772281";	//username
$partspassword = "1995May15";	//password
$partsdb = "parts";	//name of database
//
$conn = @mysql_connect($hostname,$username,$password); //legacy db
$partsconn = @mysql_connect($partshostname,$partsusername,$partspassword); 
if (!$conn || !$partsconn) {
	die("Could not connect: " . mysql_error());
}

//select database
$db_selected = mysql_select_db($db, $conn);


if (!$db_selected) {
	die ("Could not use: " . $db . mysql_error());
}

//selection query
$sql = "SELECT * FROM parts";

$result = mysql_query($sql, $conn);
$partsresult = mysql_query($sql, $conn);
//checking for failure
if (!$result) {
	die("Could not execute sql: " . mysql_error());
}

//echoing table headers
echo "<table align=center width=100%>";
	echo "<tr bgcolor=#416baf class=stroke2>";
	echo "<th align=left>Number</th>";
	echo "<th align=left>Description</th>";
	echo "<th align=left>Price</th>";
	echo "<th align=left>Weight</th>";
	echo "<th align=left>Picture</th>";
	echo "<th align=left>Purchase</th>";
	echo "</tr>";

// Loop that fetches each part and displays each variable accordingly to headers
while($part=mysql_fetch_assoc($result)) {
    $partsdb_selected = mysql_select_db($partsdb, $partsconn);
    //$onHand = $partsconn->query($qntQuery);
    $db_selected = mysql_select_db($db, $conn);
	echo "<tr>";
	echo "<td align=left>".$part[number]."</td> ";
	echo "<td align=left>".$part[description]."</td> ";
	echo "<td align=left>".$part[price]."</td> ";
	echo "<td align=left>".$part[weight]."</td> ";
	echo "<td align=left><img src='".$part[pictureURL]."' height=100 width=100 /></td>";
	echo "<td align=left>";
    echo "<input id='orderedqnty' type='number' name='orderqnty[]'> ";
    echo "In stock:" .$onHand."</td> ";
	echo "</tr>";
}

echo "</table>";
//Footer that holds the checkout button
echo "<div class='footer'><footer><p><input type='submit' style="width:100px;border:3px solid green" value='Checkout'></div>";
?>
</form>
</body>
</html>


