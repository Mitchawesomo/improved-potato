
package pdgamegui;

import java.util.*;
import java.io.*;

/**
 *
 * @author Mitch
 * z1751490
 * CSCI  470 LEON
 * Assignment 3: Prisoner's Dilemma with GUI
 * Due Date: Monday October 3rd, 2016
 * 
 * Purpose:  This class holds all the logic for the game. It obtains
 *  the strategies, the round number and both players decisions.
 */
public class PDGame
{  
  // pointer to the array list of previous player decisions
  private static ArrayList<Integer> userHistoryAL = new ArrayList();
  
  // pointer to array list of choices
  private final ArrayList<String> computerStrategiesAL = new ArrayList<>();
  
  // Create GameStat pointer
  GameStat gameStatptr = new GameStat();
  
  private int computerStrategy;
  
  private int strat;
  
  private String compStrat;
  
  // Storage for picked result
  private String result;
  
  // Storage for possible decisions
  private final String[] rslt = new String[]
  {
      "\nYou and your partner remain silent.\n You both get 2 years in prison.\n",
      "\nYour partner testifies against you and you remain silent.\n You get 5 years, they get 1\n",
      "\nYou testify against your partner and he remains silent.\n You get 1 year while they get 5\n",
      "\nYou both testify against each other.\n You both get 3 years\n"
  };
  
  // Computer's year sentence
  private int computer = 0;
  
  // Player's year sentence
  private int player = 0;
  
  // First constructor. Adds strategies to array list
  PDGame() 
  {   
      computerStrategiesAL.add("Computer Reads Strategy from Input File");
      computerStrategiesAL.add("Tit-For-Tat");
      computerStrategiesAL.add("Tit-For-Two-Tats");
      computerStrategiesAL.add("Random Choice by Computer");

    } // ends PDGame constructor
  
  // Method for Read from file
  public int FromFile()
  {
          // Read 1 or 2 from file num.txt
    try
    {
        // find file
        File file1 = new File("num.txt");
        
        Scanner fileScanner = new Scanner(file1);
        
        // Returns true if int is found
        while(fileScanner.hasNext())
        {
            // makes sure it is an int
            if(fileScanner.hasNextInt())
            {              
                // Retrieve strategy from file
                computerStrategy = fileScanner.nextInt();
                
                // Message stating int was found
                System.out.println("Found int to process" + fileScanner.nextInt());
            }
            else
            {
                // Nothing was found
                System.out.println("No int found");
            }
            
        } // ends while loop
  } // ends try
    
    // If no file found, Exception is triggered; ends program
    catch(FileNotFoundException e)
    {
        System.out.println("\nnum.txt was not found...exiting program");
        System.exit(88);
    }
    
    gameStatptr.compStrategy(1);
    
    return computerStrategy;
  }
  
  // Method for Tit-for-Tat strategy
  public int TFT()
  {
      // If first move is remain silent
      if(userHistoryAL.size() < 1)
      {
          // Computer remains silent
          computerStrategy = 1;
      }
      else
      {
          // Otherwise computer betrays as well
          computerStrategy = userHistoryAL.get(userHistoryAL.size() - 1);
      }

      gameStatptr.compStrategy(2);
      
      // returns computer's decision    
      return computerStrategy; 
  }
  
  // Method for Tit-For-Two-Tats
  public int TFTT()
  {
      // If user does not betray first two turns
      if(userHistoryAL.size() < 2)
      {
          // Computer remains silent
          computerStrategy = 1;
      }
      // If user betrays two times in a row
      else if(userHistoryAL.get(userHistoryAL.size() - 1) == 2 && userHistoryAL.get(userHistoryAL.size() - 2) == 2)
      {
          // Computer betrays
          computerStrategy = 2;
      }
      // Otherwise
      else
      {
          // Computer remains silent
          computerStrategy = 1;
      }
      
      gameStatptr.compStrategy(3);
      
      return computerStrategy;
  }
  
  // Method for Random decision
  public int RandomGame()
  {
      // Generate random number
      int ran = (int)(Math.random()*100 + 1);
      
      // If first move
      if(userHistoryAL.size() < 1)
      {
          // remain silent
          computerStrategy = 1;
      }
      // if greater, act normal
      else if(ran < 50)
      {
          computerStrategy = userHistoryAL.get(userHistoryAL.size() - 1);
      }
      // Otherwise, forgive
      else
      {
          computerStrategy = 1;
      }
      
      gameStatptr.compStrategy(4);
      
      // return computer decision
      return computerStrategy;
  }
  
   // Generates and returns computer's decision
  public String playRound(int decision)
  {   
      // Input (1 or 2) is added to list of user's moves
      userHistoryAL.add(decision);
      
      // Cycle through to call correct method
      if(strat == 1)
      {
          FromFile();
      }
      else if(strat == 2)
      {
          // Tit-For-Tat
          TFT();
          
      }
      else if(strat == 3)
      {
          // Tit-For-Two-Tats
          TFTT();
      }
      else
      {
          // Random decision
          RandomGame();
      }
      
      // If player's decision is remain silent
      if(decision == 1)
      {
          // If computer decision is remain silent
          if(computerStrategy == 1)
          {
              result = rslt[0];
              computer = 2;
              player = 2;
              
          }
          // If Computer chooses betray
          else if(computerStrategy == 2)
          {
              result = rslt[1];
              computer = 1;
              player = 5;
              
          }
      }
      // If player chooses to betray
      else if(decision == 2)
      {
          // If computer chooses to remain silent
          if(computerStrategy == 1)
          {
              result = rslt[2];
              computer = 5;
              player = 1;
          }
          // If computer also chooses to betray
          else
          {
              result = rslt[3];
              computer = 3;
              player = 3;
          }
      }
      
      // Update GlobalStats with both players sentence for the round
      gameStatptr.update(player, computer);

      System.out.println(result);
      
      return result;
  }
  
  // Returns the array of all possible strategies
  public ArrayList<String> getStrategies()
   {
    return computerStrategiesAL;
   }

  // Obtains which strategy from the string to imploy correct strategy
  public void setStrategy(int computerStrategy)
 {
    strat = computerStrategy; 
 }
  
 public String getResults()
 {
     return result;
 }
  

 // Obtains chosen game strategy (Betray or silence)
 public GameStat getStats()
 {
    return gameStatptr;
 }

 // Displays the final scores of both computer and player
 public String getScores()
 {      
    String scores = "Winner: " + gameStatptr.getWinner() + "\nYour prison sentence is:" + gameStatptr.playerYears + "\n";
    scores += "Your partner's prison sentence is " + gameStatptr.computerYears + "\n\n";

    return scores;
 } // end getScores
} // end PDGame