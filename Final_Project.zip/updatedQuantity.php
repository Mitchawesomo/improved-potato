<!--
Group: Undergrad 3
filename: updatedQuantity.php
Desc: Where the quantity is updated in our internaldb
-->
<!DOCTYPE html>
<html>
<head>
	<title>Update</title>
<style>
.footer { 
	position: fixed; 
	bottom: 0; 
	}
.stroke2
	{
	color: white;
	text-shadow:
		-1px -1px 0 #000,
		1px -1px 0 #000,
		-1px 1px 0 #000,
		1px 1px 0 #000;
	}
</style>

</head>

<h1>Quantity Updated</h1>

<?php
//
//script to login into legacy database and display content
//
$hostname = "students";	//name of server
$username = "z1772281";	//username
$password = "1995May15";	//password
$db = "z1772281";	//name of database

//connecting to database
$conn = @mysql_connect($hostname,$username,$password);
if (!$conn) {
	die("Could not connect: " . mysql_error());
}

//select database
$db_selected = mysql_select_db($db, $conn);

if (!$db_selected) {
	die ("Could not use: " . $db . mysql_error());
}

// Variables that store part number and it's quantity
$idNum = intval($_POST['id']);
$quantity = intval($_POST['quantity']);


$sql = "UPDATE internaldb SET quantity = quantity + '".$quantity."' WHERE number = '".$idNum."'";

$result = mysql_query($sql, $conn);
//checking for failure
if (!$result) {
	die("Could not execute sql: " . mysql_error());
}

// Search for part by ID# in internaldb to update quantity
$sql = "SELECT number, description, quantity FROM internaldb WHERE number = '".$idNum."'";

$result = mysql_query($sql, $conn);
//checking for failure
if (!$result) {
	die("Could not execute sql: " . mysql_error());
}

//echoing table headers
echo "<table align=center width=100%>";
	echo "<tr bgcolor=#416baf class=stroke2>";
	echo "<th align=left>Number</th>";
	echo "<th align=left>Description</th>";
	echo "<th align=left>Quantity</th>";
	echo "</tr>";

// Loop that displays variables accordingly to headers
while($part=mysql_fetch_assoc($result)) {
	echo "<tr>";
	echo "<td align=left>".$part[number]."</td> ";
	echo "<td align=left>".$part[description]."</td> ";
	echo "<td align=left>".$part[quantity]."</td> ";
	echo "</tr>";

}

?>

</body>
</html>







