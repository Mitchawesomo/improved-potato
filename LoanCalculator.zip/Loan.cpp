//*****************************************************************
// PROGRAM: Loan Calculator
// AUTHOR:  Mitch Boehning
//
// PURPOSE: This program calculates interest based on user's
//          input percentage and shows total loan amount.
//
// NOTES:
//
//*****************************************************************

#include <string>
#include <iostream>
#include <iomanip>
#include <vector>
#include <cstdlib>
#include <stdlib.h>
#include <cmath>

using namespace std;

int main()
{
  // Storage for input percentage
  double interest = 0;

  // Storage for inital loan amount
  double loan = 0;

  // Amount after paying
  double newLoan = 0;

  // Interest Rate
  double interestRate = 0;

  // Amount after interest included
  double iLoan = 0;

  // How much user wants to pay a month
  double monthPay = 0;

  double annualPay = 0; // Amount user pays a year

  double totalLoan = 0; // New amount to pay off loan

  double fullLoan = 0; // Total amount to pay off loan

  // Storage for amount of year
  int years = 1;
  int months = 1; // amount of months

  // Obtain variables
  cout << "Please enter loan amount" << endl;
  cin >> loan;

  cout << "Please enter interest percentage" << endl;
  cin >> interest;

  cout << "Please enter how much you want to pay a month" << endl;
  cin >> monthPay;

  // Determine interest rate
  interestRate = interest / 100;

  // Find Annual pay
  annualPay = 12 * monthPay;

  // Deterine if Loan will be paid off in less than a year
  if(annualPay >= loan)
  {
    // Loan will be paid off
    cout << "You will pay off the loan in less than a year! Good job!" << endl;

    // exit program
    exit(1);

  } else {  // Loan won't be paid off in a year

    cout << "You will pay $" << annualPay << " a year." << endl << endl;
  }

  // While the loan is still above amount being paid a month
  while(loan > annualPay)
  {
    // Subtract Annual pay from Loaned ammount
    newLoan = loan - annualPay;

    // Determine interest rate
    iLoan = newLoan * interestRate;

    // Add interest to total amount
    totalLoan = iLoan + newLoan;

    cout << "After " << years << " year";
    if(years > 1)
    {
      cout << "s";
    }
    cout << " you will have: $" << totalLoan << " left." << endl << endl;

    years++; // increment years

    loan = totalLoan; // Set newly calculated Loan to old loan

    fullLoan += annualPay;  // Determine full loan paid
 }

  // Add left over from loan loop to full loan
  fullLoan += totalLoan;

  // Determine how many months the final loan year will take
  while(loan >= monthPay)
  {
    // subtratct monthyPay from remaining loan
    loan = loan - monthPay;

    // Increment month
    months++;
  }

  cout << "It will take you " << years - 1 << " year";
  if(years > 1)
  {
    cout << "s";
  }
    cout << " and " << months << " month";
  if(months > 1)
  {
    cout << "s";
  }
    cout << " to pay off the loan." << endl;

  cout << "Your total loan amount to pay will be: $" << fullLoan << endl;

  return 0;
} // end main
